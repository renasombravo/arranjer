#include "Mixer.h"
#include <algorithm>
#include <chrono>

Mixer::Mixer()
    : masterVolume(1.0f)
    , numChannels(32)  // Aumentado para suportar mais canais
    , maxPolyphony(240)
    , activeVoices(0)
    , cpuUsage(0.0)
{
    // Inicializa canais com thread safety
    channels.resize(numChannels.load());
    
    // Inicializa pool de vozes para alta polifonia
    voicePool.resize(maxPolyphony.load());
    for (int i = 0; i < maxPolyphony.load(); i++)
    {
        voicePool[i].voiceId = i;
        voicePool[i].channel = -1;
        voicePool[i].active = false;
    }
}

Mixer::~Mixer()
{
    clearAllBuffers();
}

void Mixer::processAudio(juce::AudioBuffer<float>& buffer)
{
    auto startTime = std::chrono::high_resolution_clock::now();
    
    int numSamples = buffer.getNumSamples();
    int numOutputChannels = buffer.getNumChannels();
    
    // Limpa buffer de saída
    buffer.clear();
    
    // Lock para thread safety
    std::lock_guard<std::mutex> lock(channelsMutex);
    
    // Verifica se há canais em solo
    bool hasSolo = false;
    for (const auto& channel : channels)
    {
        if (channel.solo.load())
        {
            hasSolo = true;
            break;
        }
    }
    
    // Processa cada canal com otimização para alta polifonia
    for (int ch = 0; ch < numChannels.load(); ch++)
    {
        const auto& channel = channels[ch];
        
        // Verifica se o canal deve ser reproduzido
        bool shouldPlay = !channel.mute.load() && (!hasSolo || channel.solo.load());
        
        if (!shouldPlay)
            continue;
            
        // Lock do buffer do canal
        std::lock_guard<std::mutex> bufferLock(channel.bufferMutex);
        
        if (channel.audioBuffer.empty())
            continue;
            
        // Aplica volume e pan com atomic loads
        float volume = channel.volume.load();
        float pan = channel.pan.load();
        float leftGain = volume * (1.0f - std::max(0.0f, pan));
        float rightGain = volume * (1.0f + std::min(0.0f, pan));
        
        // Mistura o áudio do canal com otimização
        int channelSamples = std::min(numSamples, static_cast<int>(channel.audioBuffer.size()));
        
        // Processamento otimizado por blocos
        const float* audioData = channel.audioBuffer.data();
        float masterVol = masterVolume.load();
        
        for (int sample = 0; sample < channelSamples; sample++)
        {
            float audioSample = audioData[sample];
            
            // Canal esquerdo
            if (numOutputChannels > 0)
            {
                buffer.addSample(0, sample, audioSample * leftGain * masterVol);
            }
            
            // Canal direito
            if (numOutputChannels > 1)
            {
                buffer.addSample(1, sample, audioSample * rightGain * masterVol);
            }
        }
    }
    
    // Aplica efeitos globais e otimizações
    applyGlobalEffects(buffer);
    optimizeBufferProcessing(buffer);
    
    // Calcula uso de CPU
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);
    double blockTime = (double)numSamples / 44100.0 * 1000000.0; // em microsegundos
    cpuUsage = (double)duration.count() / blockTime * 100.0;
}

void Mixer::setMaxPolyphony(int voices)
{
    std::lock_guard<std::mutex> lock(voicePoolMutex);
    maxPolyphony = std::clamp(voices, 1, 512);
    
    // Redimensiona pool de vozes
    voicePool.resize(maxPolyphony.load());
    for (int i = 0; i < maxPolyphony.load(); i++)
    {
        if (i >= voicePool.size())
        {
            voicePool[i].voiceId = i;
            voicePool[i].channel = -1;
            voicePool[i].active = false;
        }
    }
}

void Mixer::setMaxChannels(int channels)
{
    std::lock_guard<std::mutex> lock(channelsMutex);
    numChannels = std::clamp(channels, 1, 64);
    this->channels.resize(numChannels.load());
}

void Mixer::addVoiceToChannel(int channel, int voiceId, const std::vector<float>& audioData)
{
    if (channel < 0 || channel >= numChannels.load())
        return;
        
    std::lock_guard<std::mutex> voiceLock(voicePoolMutex);
    
    // Encontra voz disponível ou reutiliza
    if (voiceId >= 0 && voiceId < voicePool.size())
    {
        voicePool[voiceId].channel = channel;
        voicePool[voiceId].audioData = audioData;
        voicePool[voiceId].active = true;
        
        // Adiciona ao buffer do canal
        std::lock_guard<std::mutex> bufferLock(channels[channel].bufferMutex);
        channels[channel].audioBuffer.insert(
            channels[channel].audioBuffer.end(),
            audioData.begin(),
            audioData.end()
        );
        
        activeVoices++;
    }
}

void Mixer::removeVoiceFromChannel(int channel, int voiceId)
{
    if (channel < 0 || channel >= numChannels.load())
        return;
        
    std::lock_guard<std::mutex> voiceLock(voicePoolMutex);
    
    if (voiceId >= 0 && voiceId < voicePool.size() && voicePool[voiceId].active)
    {
        voicePool[voiceId].active = false;
        voicePool[voiceId].channel = -1;
        voicePool[voiceId].audioData.clear();
        
        if (activeVoices.load() > 0)
            activeVoices--;
    }
}

void Mixer::optimizeBufferProcessing(juce::AudioBuffer<float>& buffer)
{
    // Otimizações específicas para alta polifonia
    int numSamples = buffer.getNumSamples();
    int numChannels = buffer.getNumChannels();
    
    // Aplicação de SIMD se disponível (simulado aqui)
    for (int ch = 0; ch < numChannels; ch++)
    {
        float* channelData = buffer.getWritePointer(ch);
        
        // Processamento otimizado por blocos de 4 samples (simulando SIMD)
        int blockSize = 4;
        int numBlocks = numSamples / blockSize;
        
        for (int block = 0; block < numBlocks; block++)
        {
            int startSample = block * blockSize;
            
            // Processa bloco de 4 samples
            for (int i = 0; i < blockSize && (startSample + i) < numSamples; i++)
            {
                int sample = startSample + i;
                // Limitador otimizado
                channelData[sample] = std::clamp(channelData[sample], -1.0f, 1.0f);
            }
        }
        
        // Processa samples restantes
        for (int sample = numBlocks * blockSize; sample < numSamples; sample++)
        {
            channelData[sample] = std::clamp(channelData[sample], -1.0f, 1.0f);
        }
    }
}

// Implementações dos métodos restantes permanecem similares mas com atomic operations
void Mixer::setChannelVolume(int channel, float volume)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        channels[channel].volume = std::clamp(volume, 0.0f, 2.0f);
    }
}

void Mixer::setChannelPan(int channel, float pan)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        channels[channel].pan = std::clamp(pan, -1.0f, 1.0f);
    }
}

void Mixer::setChannelMute(int channel, bool mute)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        channels[channel].mute = mute;
    }
}

void Mixer::setChannelSolo(int channel, bool solo)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        channels[channel].solo = solo;
    }
}

void Mixer::setChannelReverb(int channel, float reverb)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        channels[channel].reverb = std::clamp(reverb, 0.0f, 1.0f);
    }
}

void Mixer::setChannelChorus(int channel, float chorus)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        channels[channel].chorus = std::clamp(chorus, 0.0f, 1.0f);
    }
}

void Mixer::setMasterVolume(float volume)
{
    masterVolume = std::clamp(volume, 0.0f, 2.0f);
}

void Mixer::addAudioToChannel(int channel, const std::vector<float>& audioData)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        std::lock_guard<std::mutex> lock(channels[channel].bufferMutex);
        channels[channel].audioBuffer.insert(
            channels[channel].audioBuffer.end(),
            audioData.begin(),
            audioData.end()
        );
    }
}

void Mixer::clearChannelBuffer(int channel)
{
    if (channel >= 0 && channel < numChannels.load())
    {
        std::lock_guard<std::mutex> lock(channels[channel].bufferMutex);
        channels[channel].audioBuffer.clear();
    }
}

void Mixer::clearAllBuffers()
{
    std::lock_guard<std::mutex> lock(channelsMutex);
    for (auto& channel : channels)
    {
        std::lock_guard<std::mutex> bufferLock(channel.bufferMutex);
        channel.audioBuffer.clear();
    }
    
    std::lock_guard<std::mutex> voiceLock(voicePoolMutex);
    for (auto& voice : voicePool)
    {
        voice.active = false;
        voice.channel = -1;
        voice.audioData.clear();
    }
    
    activeVoices = 0;
}

float Mixer::getChannelVolume(int channel) const
{
    if (channel >= 0 && channel < numChannels.load())
    {
        return channels[channel].volume.load();
    }
    return 0.0f;
}

float Mixer::getChannelPan(int channel) const
{
    if (channel >= 0 && channel < numChannels.load())
    {
        return channels[channel].pan.load();
    }
    return 0.0f;
}

bool Mixer::isChannelMuted(int channel) const
{
    if (channel >= 0 && channel < numChannels.load())
    {
        return channels[channel].mute.load();
    }
    return false;
}

bool Mixer::isChannelSolo(int channel) const
{
    if (channel >= 0 && channel < numChannels.load())
    {
        return channels[channel].solo.load();
    }
    return false;
}

float Mixer::getMasterVolume() const
{
    return masterVolume.load();
}

void Mixer::applyGlobalEffects(juce::AudioBuffer<float>& buffer)
{
    // Implementação otimizada de efeitos globais para alta polifonia
    int numSamples = buffer.getNumSamples();
    int numChannels = buffer.getNumChannels();
    
    for (int ch = 0; ch < numChannels; ch++)
    {
        float* channelData = buffer.getWritePointer(ch);
        
        for (int sample = 0; sample < numSamples; sample++)
        {
            // Limitador com soft clipping para melhor qualidade
            float input = channelData[sample];
            if (input > 0.8f)
            {
                channelData[sample] = 0.8f + 0.2f * std::tanh((input - 0.8f) / 0.2f);
            }
            else if (input < -0.8f)
            {
                channelData[sample] = -0.8f + 0.2f * std::tanh((input + 0.8f) / 0.2f);
            }
        }
    }
}

