#pragma once

#include <JuceHeader.h>
#include <vector>
#include <algorithm>
#include <atomic>
#include <mutex>

struct MixerChannel
{
    std::atomic<float> volume;
    std::atomic<float> pan;
    std::atomic<bool> mute;
    std::atomic<bool> solo;
    std::atomic<float> reverb;
    std::atomic<float> chorus;
    std::vector<float> audioBuffer;
    std::mutex bufferMutex;
    
    MixerChannel() 
        : volume(1.0f), pan(0.0f), mute(false), solo(false), reverb(0.0f), chorus(0.0f) {}
};

/**
 * Mixer - High-performance audio mixer for 240 voice polyphony
 * Thread-safe implementation with optimized audio processing
 */
class Mixer
{
public:
    Mixer();
    ~Mixer();

    void processAudio(juce::AudioBuffer<float>& buffer);
    
    // Controles de canal
    void setChannelVolume(int channel, float volume);
    void setChannelPan(int channel, float pan);
    void setChannelMute(int channel, bool mute);
    void setChannelSolo(int channel, bool solo);
    void setChannelReverb(int channel, float reverb);
    void setChannelChorus(int channel, float chorus);
    
    // Controle master
    void setMasterVolume(float volume);
    
    // Gerenciamento de áudio para alta polifonia
    void addAudioToChannel(int channel, const std::vector<float>& audioData);
    void addVoiceToChannel(int channel, int voiceId, const std::vector<float>& audioData);
    void removeVoiceFromChannel(int channel, int voiceId);
    void clearChannelBuffer(int channel);
    void clearAllBuffers();
    
    // Configuração de polifonia
    void setMaxPolyphony(int voices);
    void setMaxChannels(int channels);
    
    // Getters
    float getChannelVolume(int channel) const;
    float getChannelPan(int channel) const;
    bool isChannelMuted(int channel) const;
    bool isChannelSolo(int channel) const;
    float getMasterVolume() const;
    int getMaxPolyphony() const { return maxPolyphony; }
    int getActiveVoices() const { return activeVoices.load(); }
    double getCpuUsage() const { return cpuUsage.load(); }

private:
    void applyGlobalEffects(juce::AudioBuffer<float>& buffer);
    void optimizeBufferProcessing(juce::AudioBuffer<float>& buffer);

    std::vector<MixerChannel> channels;
    std::atomic<float> masterVolume;
    std::atomic<int> numChannels;
    std::atomic<int> maxPolyphony;
    std::atomic<int> activeVoices;
    std::atomic<double> cpuUsage;
    
    // Thread safety
    mutable std::mutex channelsMutex;
    
    // Voice management for high polyphony
    struct VoiceData {
        int voiceId;
        int channel;
        std::vector<float> audioData;
        bool active;
    };
    
    std::vector<VoiceData> voicePool;
    std::mutex voicePoolMutex;
};


