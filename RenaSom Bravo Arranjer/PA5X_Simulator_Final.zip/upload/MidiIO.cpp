#include "MidiIO.h"

MidiIO::MidiIO()
{
    refreshMidiDevices();
    initializeKnownControllers();
}

MidiIO::~MidiIO()
{
    closeMidiInput();
    closeMidiOutput();
    closeVirtualMidiPort();
}

juce::StringArray MidiIO::getAvailableMidiInputs()
{
    juce::StringArray inputNames;
    for (auto& device : availableInputs)
        inputNames.add(device.name);
    return inputNames;
}

bool MidiIO::setMidiInput(const juce::String& deviceIdentifier)
{
    closeMidiInput();
    
    for (auto& device : availableInputs)
    {
        if (device.name == deviceIdentifier || device.identifier == deviceIdentifier)
        {
            midiInput = juce::MidiInput::openDevice(device.identifier, this);
            if (midiInput != nullptr)
            {
                midiInput->start();
                DBG("MIDI Input opened: " << device.name);
                return true;
            }
        }
    }
    DBG("Failed to open MIDI input: " << deviceIdentifier);
    return false;
}

void MidiIO::closeMidiInput()
{
    if (midiInput != nullptr)
    {
        midiInput->stop();
        midiInput.reset();
        DBG("MIDI Input closed");
    }
}

juce::StringArray MidiIO::getAvailableMidiOutputs()
{
    juce::StringArray outputNames;
    for (auto& device : availableOutputs)
        outputNames.add(device.name);
    return outputNames;
}

bool MidiIO::setMidiOutput(const juce::String& deviceIdentifier)
{
    closeMidiOutput();
    
    for (auto& device : availableOutputs)
    {
        if (device.name == deviceIdentifier || device.identifier == deviceIdentifier)
        {
            midiOutput = juce::MidiOutput::openDevice(device.identifier);
            if (midiOutput != nullptr)
            {
                DBG("MIDI Output opened: " << device.name);
                return true;
            }
        }
    }
    DBG("Failed to open MIDI output: " << deviceIdentifier);
    return false;
}

void MidiIO::closeMidiOutput()
{
    if (midiOutput != nullptr)
    {
        midiOutput.reset();
        DBG("MIDI Output closed");
    }
}

void MidiIO::sendMidiMessage(const juce::MidiMessage& message)
{
    if (midiOutput != nullptr)
        midiOutput->sendMessageNow(message);
        
    if (virtualMidiOutput != nullptr)
        virtualMidiOutput->sendMessageNow(message);
}

void MidiIO::startMidiClock()
{
    midiClockEnabled = true;
    midiClockCounter = 0;
    
    // Envia MIDI Start
    juce::MidiMessage startMessage = juce::MidiMessage::midiStart();
    sendMidiMessage(startMessage);
    DBG("MIDI Clock started");
}

void MidiIO::stopMidiClock()
{
    midiClockEnabled = false;
    
    // Envia MIDI Stop
    juce::MidiMessage stopMessage = juce::MidiMessage::midiStop();
    sendMidiMessage(stopMessage);
    DBG("MIDI Clock stopped");
}

void MidiIO::sendMidiClock()
{
    if (midiClockEnabled)
    {
        juce::MidiMessage clockMessage = juce::MidiMessage::midiClock();
        sendMidiMessage(clockMessage);
        midiClockCounter++;
    }
}

void MidiIO::setMidiClockTempo(double bpm)
{
    midiClockTempo = bpm;
    DBG("MIDI Clock tempo set to: " << bpm << " BPM");
}

void MidiIO::refreshMidiDevices()
{
    availableInputs = juce::MidiInput::getAvailableDevices();
    availableOutputs = juce::MidiOutput::getAvailableDevices();
    
    DBG("MIDI devices refreshed - Inputs: " << availableInputs.size() 
        << ", Outputs: " << availableOutputs.size());
}

bool MidiIO::isMidiInputOpen() const
{
    return midiInput != nullptr;
}

bool MidiIO::isMidiOutputOpen() const
{
    return midiOutput != nullptr;
}

std::vector<MidiControllerInfo> MidiIO::detectControllers()
{
    std::vector<MidiControllerInfo> controllers;
    
    for (auto& device : availableInputs)
    {
        MidiControllerInfo info;
        info.name = device.name;
        info.identifier = device.identifier;
        
        // Detecta características do controlador
        if (is88KeyController(device.name))
        {
            info.numKeys = 88;
            info.hasModWheel = true;
            info.hasPitchBend = true;
            info.hasSustainPedal = true;
        }
        else if (device.name.containsIgnoreCase("61"))
        {
            info.numKeys = 61;
            info.hasModWheel = true;
            info.hasPitchBend = true;
            info.hasSustainPedal = true;
        }
        else if (device.name.containsIgnoreCase("49"))
        {
            info.numKeys = 49;
            info.hasModWheel = true;
            info.hasPitchBend = true;
            info.hasSustainPedal = false;
        }
        else
        {
            info.numKeys = 25; // Padrão
            info.hasModWheel = false;
            info.hasPitchBend = false;
            info.hasSustainPedal = false;
        }
        
        info.isKontakt8Compatible = isKontakt8Controller(device.name);
        
        controllers.push_back(info);
        DBG("Detected controller: " << info.name << " (" << info.numKeys << " keys)");
    }
    
    return controllers;
}

bool MidiIO::isKontakt8Controller(const juce::String& deviceName)
{
    // Lista de controladores compatíveis com Kontakt 8
    juce::StringArray kontakt8Controllers = {
        "Native Instruments",
        "Komplete Kontrol",
        "Maschine",
        "Arturia",
        "Novation",
        "Akai",
        "M-Audio",
        "Roland",
        "Yamaha",
        "Korg"
    };
    
    for (auto& controller : kontakt8Controllers)
    {
        if (deviceName.containsIgnoreCase(controller))
            return true;
    }
    
    return false;
}

bool MidiIO::is88KeyController(const juce::String& deviceName)
{
    return deviceName.containsIgnoreCase("88") ||
           deviceName.containsIgnoreCase("piano") ||
           deviceName.containsIgnoreCase("stage") ||
           deviceName.containsIgnoreCase("digital piano");
}

void MidiIO::startMidiLearn(std::function<void(int, int)> callback)
{
    midiLearning = true;
    midiLearnCallback = callback;
    DBG("MIDI Learn started");
}

void MidiIO::stopMidiLearn()
{
    midiLearning = false;
    midiLearnCallback = nullptr;
    DBG("MIDI Learn stopped");
}

bool MidiIO::isMidiLearning() const
{
    return midiLearning;
}

bool MidiIO::createVirtualMidiPort(const juce::String& portName)
{
    closeVirtualMidiPort();
    
    // Cria porta MIDI virtual para comunicação com Kontakt8
    virtualMidiOutput = juce::MidiOutput::createNewDevice(portName);
    if (virtualMidiOutput != nullptr)
    {
        DBG("Virtual MIDI port created: " << portName);
        return true;
    }
    
    DBG("Failed to create virtual MIDI port: " << portName);
    return false;
}

void MidiIO::closeVirtualMidiPort()
{
    if (virtualMidiOutput != nullptr)
    {
        virtualMidiOutput.reset();
        DBG("Virtual MIDI port closed");
    }
}

bool MidiIO::hasVirtualMidiPort() const
{
    return virtualMidiOutput != nullptr;
}

void MidiIO::setNoteOnCallback(std::function<void(int, int, int)> callback)
{
    noteOnCallback = callback;
}

void MidiIO::setNoteOffCallback(std::function<void(int, int, int)> callback)
{
    noteOffCallback = callback;
}

void MidiIO::setControlChangeCallback(std::function<void(int, int, int)> callback)
{
    controlChangeCallback = callback;
}

void MidiIO::setPitchBendCallback(std::function<void(int, int)> callback)
{
    pitchBendCallback = callback;
}

void MidiIO::handleIncomingMidiMessage(juce::MidiInput* source, const juce::MidiMessage& message)
{
    if (message.isNoteOn())
    {
        int channel = message.getChannel();
        int note = message.getNoteNumber();
        int velocity = message.getVelocity();
        
        DBG("Note ON - Ch:" << channel << " Note:" << note << " Vel:" << velocity);
        
        if (noteOnCallback)
            noteOnCallback(channel, note, velocity);
            
        // Encaminha para Kontakt8 se porta virtual estiver ativa
        if (virtualMidiOutput)
            virtualMidiOutput->sendMessageNow(message);
    }
    else if (message.isNoteOff())
    {
        int channel = message.getChannel();
        int note = message.getNoteNumber();
        int velocity = message.getVelocity();
        
        DBG("Note OFF - Ch:" << channel << " Note:" << note << " Vel:" << velocity);
        
        if (noteOffCallback)
            noteOffCallback(channel, note, velocity);
            
        if (virtualMidiOutput)
            virtualMidiOutput->sendMessageNow(message);
    }
    else if (message.isController())
    {
        int channel = message.getChannel();
        int controller = message.getControllerNumber();
        int value = message.getControllerValue();
        
        DBG("CC - Ch:" << channel << " CC:" << controller << " Val:" << value);
        
        if (midiLearning && midiLearnCallback)
        {
            midiLearnCallback(controller, value);
            stopMidiLearn();
        }
        
        if (controlChangeCallback)
            controlChangeCallback(channel, controller, value);
            
        if (virtualMidiOutput)
            virtualMidiOutput->sendMessageNow(message);
    }
    else if (message.isPitchWheel())
    {
        int channel = message.getChannel();
        int pitchValue = message.getPitchWheelValue();
        
        DBG("Pitch Bend - Ch:" << channel << " Val:" << pitchValue);
        
        if (pitchBendCallback)
            pitchBendCallback(channel, pitchValue);
            
        if (virtualMidiOutput)
            virtualMidiOutput->sendMessageNow(message);
    }
    else
    {
        // Encaminha outras mensagens MIDI
        if (virtualMidiOutput)
            virtualMidiOutput->sendMessageNow(message);
    }
}

void MidiIO::initializeKnownControllers()
{
    // Inicializa base de dados de controladores conhecidos
    MidiControllerInfo kontrol88;
    kontrol88.name = "Komplete Kontrol S88";
    kontrol88.numKeys = 88;
    kontrol88.hasModWheel = true;
    kontrol88.hasPitchBend = true;
    kontrol88.hasSustainPedal = true;
    kontrol88.isKontakt8Compatible = true;
    knownControllers["Komplete Kontrol S88"] = kontrol88;
    
    MidiControllerInfo arturia88;
    arturia88.name = "Arturia KeyLab 88";
    arturia88.numKeys = 88;
    arturia88.hasModWheel = true;
    arturia88.hasPitchBend = true;
    arturia88.hasSustainPedal = true;
    arturia88.isKontakt8Compatible = true;
    knownControllers["Arturia KeyLab 88"] = arturia88;
    
    MidiControllerInfo maudio88;
    maudio88.name = "M-Audio Hammer 88";
    maudio88.numKeys = 88;
    maudio88.hasModWheel = true;
    maudio88.hasPitchBend = true;
    maudio88.hasSustainPedal = true;
    maudio88.isKontakt8Compatible = true;
    knownControllers["M-Audio Hammer 88"] = maudio88;
    
    DBG("Known controllers database initialized");
}

