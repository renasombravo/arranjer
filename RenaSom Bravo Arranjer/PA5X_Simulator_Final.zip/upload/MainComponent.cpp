#include "MainComponent.h"

//==============================================================================
MainComponent::MainComponent()
    : virtualKeyboard(keyboardState, juce::MidiKeyboardComponent::horizontalKeyboard)
    , isPlaying(false)
{
    // Inicializa componentes
    audioEngine = std::make_unique<AudioEngine>();
    midiIO = std::make_unique<MidiIO>();
    tempoScheduler = std::make_unique<TempoScheduler>();
    virtualBand = std::make_unique<VirtualBand>();
    kontakt8 = std::make_unique<Kontakt8Integration>();
    
    chordEngine = std::make_unique<ChordEngine>();
    styleParser = std::make_unique<StyleParser>();
    accompanimentGenerator = std::make_unique<AccompanimentGenerator>();
    
    soundFontLoader = std::make_unique<SoundFontLoader>();
    mixer = std::make_unique<Mixer>();
    effectsProcessor = std::make_unique<EffectsProcessor>();
    
    setupKorgPA5XInterface();
    setupMIDI();
    setupAudio();
    
    // Inicializa banda virtual com 240 vozes de polifonia
    virtualBand->initialize(midiIO.get(), soundFontLoader.get());
    
    // Inicializa Kontakt8
    kontakt8->initialize(midiIO.get());
    
    // Timer para atualizações da UI
    startTimer(50); // 20 FPS para responsividade
    
    // Configura tamanho da janela (proporção do PA5X)
    setSize(1200, 800);
    
    // Inicia áudio
    setAudioChannels(0, 2);
}

MainComponent::~MainComponent()
{
    shutdownAudio();
    stopTimer();
}

//==============================================================================
void MainComponent::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    if (audioEngine)
        audioEngine->prepareToPlay(samplesPerBlockExpected, sampleRate);
        
    if (effectsProcessor)
        effectsProcessor->prepare(sampleRate, samplesPerBlockExpected);
        
    if (tempoScheduler)
        tempoScheduler->setSampleRate(sampleRate);
}

void MainComponent::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    bufferToFill.clearActiveBufferRegion();
    
    if (!audioEngine || !mixer)
        return;
    
    // Processa áudio do motor principal
    audioEngine->getNextAudioBlock(bufferToFill);
    
    // Processa mixer com 240 vozes de polifonia
    mixer->processAudio(*bufferToFill.buffer);
    
    // Aplica efeitos
    if (effectsProcessor)
        effectsProcessor->processAudio(*bufferToFill.buffer);
    
    // Processa acompanhamento se estiver tocando
    if (isPlaying && accompanimentGenerator)
    {
        auto midiEvents = accompanimentGenerator->getNextMidiEvents(
            bufferToFill.numSamples, 
            audioEngine->getSampleRate()
        );
        
        // Envia eventos MIDI para a banda virtual
        for (const auto& event : midiEvents)
        {
            if (event.isNoteOn())
            {
                virtualBand->playNote(event.getChannel(), event.getNoteNumber(), event.getVelocity());
            }
            else if (event.isNoteOff())
            {
                virtualBand->stopNote(event.getChannel(), event.getNoteNumber());
            }
        }
    }
}

void MainComponent::releaseResources()
{
    if (audioEngine)
        audioEngine->releaseResources();
}

//==============================================================================
void MainComponent::paint(juce::Graphics& g)
{
    // Fundo preto profundo estilo Korg PA5X
    g.fillAll(juce::Colour(0xff0a0a0a));
    
    // Gradiente metálico no topo (estilo PA5X)
    juce::ColourGradient topGradient(juce::Colour(0xff2a2a2a), 0, 0, 
                                    juce::Colour(0xff0a0a0a), 0, 120, false);
    g.setGradientFill(topGradient);
    g.fillRect(0, 0, getWidth(), 120);
    
    // Borda metálica superior
    g.setColour(juce::Colour(0xff404040));
    g.fillRect(0, 0, getWidth(), 3);
    g.setColour(juce::Colour(0xff606060));
    g.fillRect(0, 3, getWidth(), 1);
    
    // Logo/Título estilo Korg PA5X
    g.setColour(juce::Colour(0xff00d4aa)); // Verde-azulado Korg característico
    g.setFont(juce::Font("Arial", 32.0f, juce::Font::bold));
    g.drawText("PA5X SIMULATOR", 20, 15, 450, 40, juce::Justification::left);
    
    g.setColour(juce::Colour(0xffe0e0e0));
    g.setFont(juce::Font("Arial", 16.0f, juce::Font::plain));
    g.drawText("88 KEYS • 240 POLYPHONY • PROFESSIONAL ARRANGER", 20, 55, 600, 25, juce::Justification::left);
    
    // Painel de status com fundo escuro
    auto statusArea = juce::Rectangle<int>(getWidth() - 250, 10, 240, 80);
    g.setColour(juce::Colour(0xff1a1a1a));
    g.fillRoundedRectangle(statusArea.toFloat(), 5.0f);
    g.setColour(juce::Colour(0xff404040));
    g.drawRoundedRectangle(statusArea.toFloat(), 5.0f, 1.0f);
    
    // Status da conexão MIDI
    if (midiIO && midiIO->isMidiInputOpen())
    {
        g.setColour(juce::Colour(0xff00d4aa));
        g.fillEllipse(getWidth() - 230, 25, 14, 14);
        g.setColour(juce::Colours::white);
        g.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
        g.drawText("MIDI IN", getWidth() - 210, 23, 80, 18, juce::Justification::left);
    }
    else
    {
        g.setColour(juce::Colour(0xff666666));
        g.fillEllipse(getWidth() - 230, 25, 14, 14);
        g.setColour(juce::Colour(0xff999999));
        g.setFont(juce::Font("Arial", 12.0f, juce::Font::plain));
        g.drawText("MIDI IN", getWidth() - 210, 23, 80, 18, juce::Justification::left);
    }
    
    // Status Kontakt8
    if (kontakt8 && kontakt8->isConnected())
    {
        g.setColour(juce::Colour(0xff0099ff));
        g.fillEllipse(getWidth() - 230, 50, 14, 14);
        g.setColour(juce::Colours::white);
        g.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
        g.drawText("KONTAKT8", getWidth() - 210, 48, 80, 18, juce::Justification::left);
    }
    else
    {
        g.setColour(juce::Colour(0xff666666));
        g.fillEllipse(getWidth() - 230, 50, 14, 14);
        g.setColour(juce::Colour(0xff999999));
        g.setFont(juce::Font("Arial", 12.0f, juce::Font::plain));
        g.drawText("KONTAKT8", getWidth() - 210, 48, 80, 18, juce::Justification::left);
    }
    
    // Separadores estilo PA5X com gradiente
    g.setColour(juce::Colour(0xff404040));
    g.drawLine(0, 120, getWidth(), 120, 2);
    g.setColour(juce::Colour(0xff202020));
    g.drawLine(0, 122, getWidth(), 122, 1);
    
    g.setColour(juce::Colour(0xff303030));
    g.drawLine(0, 220, getWidth(), 220, 1);
    g.drawLine(0, 370, getWidth(), 370, 1);
    
    // Display de tempo com fundo LCD estilo PA5X
    auto tempoDisplayArea = juce::Rectangle<int>(getWidth() - 200, 130, 180, 60);
    
    // Fundo LCD escuro
    g.setColour(juce::Colour(0xff0d1117));
    g.fillRoundedRectangle(tempoDisplayArea.toFloat(), 8.0f);
    
    // Borda do display
    g.setColour(juce::Colour(0xff404040));
    g.drawRoundedRectangle(tempoDisplayArea.toFloat(), 8.0f, 2.0f);
    g.setColour(juce::Colour(0xff606060));
    g.drawRoundedRectangle(tempoDisplayArea.reduced(2).toFloat(), 6.0f, 1.0f);
    
    // Texto do tempo com fonte digital
    g.setColour(juce::Colour(0xff00d4aa));
    g.setFont(juce::Font("Courier New", 28.0f, juce::Font::bold));
    juce::String tempoText = juce::String(virtualBand ? virtualBand->getTempo() : 120);
    g.drawText(tempoText, tempoDisplayArea.reduced(10, 5), juce::Justification::centred);
    
    g.setColour(juce::Colour(0xff888888));
    g.setFont(juce::Font("Arial", 11.0f, juce::Font::plain));
    g.drawText("BPM", tempoDisplayArea.getX() + 10, tempoDisplayArea.getBottom() - 20, 50, 15, juce::Justification::left);
    
    // Indicador de reprodução
    if (isPlaying)
    {
        g.setColour(juce::Colour(0xff00ff00));
        g.fillEllipse(tempoDisplayArea.getRight() - 25, tempoDisplayArea.getY() + 10, 12, 12);
        g.setColour(juce::Colours::white);
        g.setFont(juce::Font("Arial", 9.0f, juce::Font::bold));
        g.drawText("PLAY", tempoDisplayArea.getRight() - 45, tempoDisplayArea.getY() + 25, 40, 12, juce::Justification::centred);
    }
}

void MainComponent::resized()
{
    auto area = getLocalBounds();
    area.removeFromTop(100); // Espaço para cabeçalho
    
    // Seção de controles principais (estilo PA5X)
    auto mainControlsArea = area.removeFromTop(100);
    
    // Botões de transporte (estilo PA5X)
    auto transportArea = mainControlsArea.removeFromLeft(300);
    startStopButton.setBounds(transportArea.removeFromLeft(80).reduced(5));
    drumPlayButton.setBounds(transportArea.removeFromLeft(80).reduced(5));
    drumPauseButton.setBounds(transportArea.removeFromLeft(80).reduced(5));
    syncStartButton.setBounds(transportArea.removeFromLeft(50).reduced(5));
    
    // Controles de tempo
    auto tempoArea = mainControlsArea.removeFromLeft(200);
    tempoDownButton.setBounds(tempoArea.removeFromLeft(40).reduced(5));
    tempoSlider.setBounds(tempoArea.removeFromLeft(120).reduced(5));
    tempoUpButton.setBounds(tempoArea.removeFromLeft(40).reduced(5));
    
    // Botão Kontakt8
    kontakt8ConnectButton.setBounds(mainControlsArea.removeFromLeft(120).reduced(5));
    
    // Seção de dispositivos MIDI
    auto midiArea = area.removeFromTop(50);
    midiInputLabel.setBounds(midiArea.removeFromLeft(80).reduced(5));
    midiInputCombo.setBounds(midiArea.removeFromLeft(250).reduced(5));
    midiOutputLabel.setBounds(midiArea.removeFromLeft(80).reduced(5));
    midiOutputCombo.setBounds(midiArea.removeFromLeft(250).reduced(5));
    
    // Seção de estilos e ritmos (estilo PA5X)
    auto styleArea = area.removeFromTop(150);
    
    // Categorias de estilo
    auto categoryArea = styleArea.removeFromTop(40);
    for (int i = 0; i < styleCategoryButtons.size(); i++)
    {
        styleCategoryButtons[i]->setBounds(categoryArea.removeFromLeft(100).reduced(2));
    }
    
    // Lista de estilos
    auto styleListArea = styleArea.removeFromTop(70);
    for (int i = 0; i < styleButtons.size(); i++)
    {
        styleButtons[i]->setBounds(styleListArea.removeFromLeft(120).reduced(2));
    }
    
    // Variações de estilo
    auto variationArea = styleArea.removeFromTop(40);
    introButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    variationAButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    variationBButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    variationCButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    variationDButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    fillInButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    breakButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    endingButton.setBounds(variationArea.removeFromLeft(80).reduced(2));
    
    // Controles de acorde
    auto chordArea = area.removeFromTop(60);
    chordLabel.setBounds(chordArea.removeFromLeft(100).reduced(5));
    chordCombo.setBounds(chordArea.removeFromLeft(150).reduced(5));
    chordModeLabel.setBounds(chordArea.removeFromLeft(100).reduced(5));
    chordModeCombo.setBounds(chordArea.removeFromLeft(150).reduced(5));
    
    // Teclado virtual (88 teclas)
    virtualKeyboard.setBounds(area.removeFromBottom(120).reduced(5));
    
    // Área restante para controles de volume/mixer
    setupMixerControls(area);
}

//==============================================================================
void MainComponent::timerCallback()
{
    updateKontakt8Status();
    updateDisplays();
    repaint();
}

//==============================================================================
void MainComponent::setupKorgPA5XInterface()
{
    // Configura Look and Feel escuro estilo PA5X
    getLookAndFeel().setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1a1a1a));
    getLookAndFeel().setColour(juce::TextButton::textColourOffId, juce::Colour(0xffe0e0e0));
    getLookAndFeel().setColour(juce::TextButton::textColourOnId, juce::Colour(0xff00d4aa));
    getLookAndFeel().setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff2a2a2a));
    getLookAndFeel().setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1117));
    getLookAndFeel().setColour(juce::ComboBox::textColourId, juce::Colour(0xffe0e0e0));
    getLookAndFeel().setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff404040));
    getLookAndFeel().setColour(juce::Slider::backgroundColourId, juce::Colour(0xff0d1117));
    getLookAndFeel().setColour(juce::Slider::thumbColourId, juce::Colour(0xff00d4aa));
    getLookAndFeel().setColour(juce::Slider::trackColourId, juce::Colour(0xff404040));
    
    // Botões de transporte estilo PA5X com cores características
    startStopButton.setButtonText("START/STOP");
    startStopButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff006633)); // Verde escuro
    startStopButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    startStopButton.onClick = [this] { startStopButtonClicked(); };
    addAndMakeVisible(startStopButton);
    
    drumPlayButton.setButtonText("DRUM PLAY");
    drumPlayButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff0066aa)); // Azul PA5X
    drumPlayButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    drumPlayButton.onClick = [this] { drumPlayButtonClicked(); };
    addAndMakeVisible(drumPlayButton);
    
    drumPauseButton.setButtonText("DRUM PAUSE");
    drumPauseButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff996600)); // Laranja escuro
    drumPauseButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    drumPauseButton.onClick = [this] { drumPauseButtonClicked(); };
    addAndMakeVisible(drumPauseButton);
    
    syncStartButton.setButtonText("SYNC");
    syncStartButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff663366)); // Roxo escuro
    syncStartButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    syncStartButton.onClick = [this] { syncStartButtonClicked(); };
    addAndMakeVisible(syncStartButton);
    
    // Controles de tempo estilo PA5X
    tempoDownButton.setButtonText("◄");
    tempoDownButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff2a2a2a));
    tempoDownButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff00d4aa));
    tempoDownButton.onClick = [this] { tempoDownButtonClicked(); };
    addAndMakeVisible(tempoDownButton);
    
    tempoUpButton.setButtonText("►");
    tempoUpButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff2a2a2a));
    tempoUpButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff00d4aa));
    tempoUpButton.onClick = [this] { tempoUpButtonClicked(); };
    addAndMakeVisible(tempoUpButton);
    
    tempoSlider.setRange(60, 200, 1);
    tempoSlider.setValue(120);
    tempoSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    tempoSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    tempoSlider.setColour(juce::Slider::backgroundColourId, juce::Colour(0xff0d1117));
    tempoSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff00d4aa));
    tempoSlider.setColour(juce::Slider::trackColourId, juce::Colour(0xff404040));
    tempoSlider.onValueChange = [this] { tempoSliderChanged(); };
    addAndMakeVisible(tempoSlider);
    
    // Dispositivos MIDI com estilo PA5X
    midiInputLabel.setText("MIDI IN", juce::dontSendNotification);
    midiInputLabel.setColour(juce::Label::textColourId, juce::Colour(0xffe0e0e0));
    midiInputLabel.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
    addAndMakeVisible(midiInputLabel);
    
    midiInputCombo.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1117));
    midiInputCombo.setColour(juce::ComboBox::textColourId, juce::Colour(0xffe0e0e0));
    midiInputCombo.setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff404040));
    midiInputCombo.onChange = [this] { midiInputChanged(); };
    addAndMakeVisible(midiInputCombo);
    
    midiOutputLabel.setText("MIDI OUT", juce::dontSendNotification);
    midiOutputLabel.setColour(juce::Label::textColourId, juce::Colour(0xffe0e0e0));
    midiOutputLabel.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
    addAndMakeVisible(midiOutputLabel);
    
    midiOutputCombo.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1117));
    midiOutputCombo.setColour(juce::ComboBox::textColourId, juce::Colour(0xffe0e0e0));
    midiOutputCombo.setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff404040));
    midiOutputCombo.onChange = [this] { midiOutputChanged(); };
    addAndMakeVisible(midiOutputCombo);
    
    // Kontakt8 com cor característica
    kontakt8ConnectButton.setButtonText("KONTAKT8");
    kontakt8ConnectButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff0099ff));
    kontakt8ConnectButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    kontakt8ConnectButton.onClick = [this] { kontakt8ConnectButtonClicked(); };
    addAndMakeVisible(kontakt8ConnectButton);
    
    // Categorias de estilo (estilo PA5X) com cores diferenciadas
    juce::StringArray categories = {"POP", "ROCK", "JAZZ", "LATIN", "WORLD", "DANCE", "BALLAD", "COUNTRY"};
    juce::Array<juce::Colour> categoryColors = {
        juce::Colour(0xff4a90e2), // Azul
        juce::Colour(0xffe74c3c), // Vermelho
        juce::Colour(0xfff39c12), // Laranja
        juce::Colour(0xff27ae60), // Verde
        juce::Colour(0xff9b59b6), // Roxo
        juce::Colour(0xffe91e63), // Rosa
        juce::Colour(0xff34495e), // Cinza azulado
        juce::Colour(0xff795548)  // Marrom
    };
    
    for (int i = 0; i < categories.size(); i++)
    {
        auto button = std::make_unique<juce::TextButton>(categories[i]);
        button->setColour(juce::TextButton::buttonColourId, categoryColors[i]);
        button->setColour(juce::TextButton::textColourOffId, juce::Colours::white);
        button->onClick = [this, i] { styleCategorySelected(i); };
        styleCategoryButtons.push_back(std::move(button));
        addAndMakeVisible(styleCategoryButtons.back().get());
    }
    
    // Estilos (simulando PA5X) com cores neutras
    juce::StringArray styles = {"8Beat Pop", "16Beat", "Ballad", "Bossa Nova", "Samba", "Rock", "Jazz Swing", "Country"};
    for (int i = 0; i < styles.size(); i++)
    {
        auto button = std::make_unique<juce::TextButton>(styles[i]);
        button->setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1a1a1a));
        button->setColour(juce::TextButton::textColourOffId, juce::Colour(0xffe0e0e0));
        button->setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff00d4aa));
        button->onClick = [this, i] { styleSelected(i); };
        styleButtons.push_back(std::move(button));
        addAndMakeVisible(styleButtons.back().get());
    }
    
    // Variações estilo PA5X com cores características
    introButton.setButtonText("INTRO");
    introButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff27ae60)); // Verde
    introButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    introButton.onClick = [this] { variationSelected(StyleSectionType::INTRO_A); };
    addAndMakeVisible(introButton);
    
    variationAButton.setButtonText("VAR A");
    variationAButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff3498db)); // Azul claro
    variationAButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    variationAButton.onClick = [this] { variationSelected(StyleSectionType::MAIN_A); };
    addAndMakeVisible(variationAButton);
    
    variationBButton.setButtonText("VAR B");
    variationBButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff2980b9)); // Azul médio
    variationBButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    variationBButton.onClick = [this] { variationSelected(StyleSectionType::MAIN_B); };
    addAndMakeVisible(variationBButton);
    
    variationCButton.setButtonText("VAR C");
    variationCButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1f4e79)); // Azul escuro
    variationCButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    variationCButton.onClick = [this] { variationSelected(StyleSectionType::MAIN_C); };
    addAndMakeVisible(variationCButton);
    
    variationDButton.setButtonText("VAR D");
    variationDButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff0f3460)); // Azul muito escuro
    variationDButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    variationDButton.onClick = [this] { variationSelected(StyleSectionType::MAIN_D); };
    addAndMakeVisible(variationDButton);
    
    fillInButton.setButtonText("FILL IN");
    fillInButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xfff39c12)); // Laranja
    fillInButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    fillInButton.onClick = [this] { variationSelected(StyleSectionType::FILL_IN_AA); };
    addAndMakeVisible(fillInButton);
    
    breakButton.setButtonText("BREAK");
    breakButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff9b59b6)); // Roxo
    breakButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    breakButton.onClick = [this] { variationSelected(StyleSectionType::BREAK_FILL); };
    addAndMakeVisible(breakButton);
    
    endingButton.setButtonText("ENDING");
    endingButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xffe74c3c)); // Vermelho
    endingButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    endingButton.onClick = [this] { variationSelected(StyleSectionType::ENDING_A); };
    addAndMakeVisible(endingButton);
    
    // Controles de acorde com estilo PA5X
    chordLabel.setText("CHORD", juce::dontSendNotification);
    chordLabel.setColour(juce::Label::textColourId, juce::Colour(0xffe0e0e0));
    chordLabel.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
    addAndMakeVisible(chordLabel);
    
    chordCombo.addItem("C", 1);
    chordCombo.addItem("Dm", 2);
    chordCombo.addItem("Em", 3);
    chordCombo.addItem("F", 4);
    chordCombo.addItem("G", 5);
    chordCombo.addItem("Am", 6);
    chordCombo.addItem("G7", 7);
    chordCombo.setSelectedId(1);
    chordCombo.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1117));
    chordCombo.setColour(juce::ComboBox::textColourId, juce::Colour(0xffe0e0e0));
    chordCombo.setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff404040));
    chordCombo.onChange = [this] { chordChanged(); };
    addAndMakeVisible(chordCombo);
    
    chordModeLabel.setText("MODE", juce::dontSendNotification);
    chordModeLabel.setColour(juce::Label::textColourId, juce::Colour(0xffe0e0e0));
    chordModeLabel.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
    addAndMakeVisible(chordModeLabel);
    
    chordModeCombo.addItem("FINGERED", 1);
    chordModeCombo.addItem("FULL KEYBOARD", 2);
    chordModeCombo.addItem("SINGLE FINGER", 3);
    chordModeCombo.setSelectedId(1);
    chordModeCombo.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1117));
    chordModeCombo.setColour(juce::ComboBox::textColourId, juce::Colour(0xffe0e0e0));
    chordModeCombo.setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff404040));
    addAndMakeVisible(chordModeCombo);
    
    // Teclado virtual (88 teclas) com cores PA5X
    virtualKeyboard.setColour(juce::MidiKeyboardComponent::whiteNoteColourId, juce::Colour(0xfff8f8f8));
    virtualKeyboard.setColour(juce::MidiKeyboardComponent::blackNoteColourId, juce::Colour(0xff1a1a1a));
    virtualKeyboard.setColour(juce::MidiKeyboardComponent::keySeparatorLineColourId, juce::Colour(0xff404040));
    virtualKeyboard.setColour(juce::MidiKeyboardComponent::mouseOverKeyOverlayColourId, juce::Colour(0x4000d4aa));
    virtualKeyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId, juce::Colour(0x8000d4aa));
    addAndMakeVisible(virtualKeyboard);
}
void MainComponent::setupMIDI()
{
    if (!midiIO)
        return;
    
    // Detecta controladores
    auto controllers = midiIO->detectControllers();
    
    for (const auto& controller : controllers)
    {
        DBG("Detected controller: " << controller.name << " (" << controller.numKeys << " keys)");
        
        if (controller.isKontakt8Compatible)
        {
            DBG("Controller is Kontakt8 compatible");
        }
    }
    
    // Atualiza lista de dispositivos MIDI
    updateMidiDeviceList();
}

void MainComponent::setupAudio()
{
    if (!audioEngine)
        return;
    
    // Configura motor de áudio com 240 vozes de polifonia
    audioEngine->initialize();
    audioEngine->setMaxPolyphony(240);
    
    // Configura mixer para alta polifonia
    if (mixer)
    {
        mixer->setMaxPolyphony(240);
        mixer->setMaxChannels(32);
    }
    
    // Configura banda virtual para 240 vozes
    if (virtualBand)
    {
        virtualBand->setMaxPolyphony(240);
    }
}

void MainComponent::setupMixerControls(juce::Rectangle<int> area)
{
    // Implementa controles de mixer estilo PA5X
    // (Seria expandido com sliders de volume, pan, etc.)
}

void MainComponent::updateMidiDeviceList()
{
    if (!midiIO)
        return;
    
    midiIO->refreshMidiDevices();
    
    // Atualiza combo de entrada
    midiInputCombo.clear();
    midiInputCombo.addItem("None", 1);
    auto inputs = midiIO->getAvailableMidiInputs();
    for (int i = 0; i < inputs.size(); i++)
    {
        midiInputCombo.addItem(inputs[i], i + 2);
    }
    
    // Atualiza combo de saída
    midiOutputCombo.clear();
    midiOutputCombo.addItem("None", 1);
    auto outputs = midiIO->getAvailableMidiOutputs();
    for (int i = 0; i < outputs.size(); i++)
    {
        midiOutputCombo.addItem(outputs[i], i + 2);
    }
}

void MainComponent::updateKontakt8Status()
{
    // Atualiza status do Kontakt8
}

void MainComponent::updateDisplays()
{
    // Atualiza displays estilo PA5X
}

// Implementações dos callbacks dos botões
void MainComponent::startStopButtonClicked()
{
    if (!virtualBand)
        return;
        
    if (virtualBand->isPlaying())
    {
        virtualBand->stop();
        if (accompanimentGenerator)
            accompanimentGenerator->stop();
        isPlaying = false;
        startStopButton.setButtonText("START/STOP");
        startStopButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff006633));
    }
    else
    {
        virtualBand->start();
        if (accompanimentGenerator)
            accompanimentGenerator->start();
        isPlaying = true;
        startStopButton.setButtonText("STOP");
        startStopButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xffcc3300));
    }
}

void MainComponent::drumPlayButtonClicked()
{
    if (!virtualBand)
        return;
    
    // Inicia apenas a bateria (canal 10)
    virtualBand->drumPlay();
    
    // Muta outros instrumentos se necessário
    virtualBand->muteInstrument(1, true);   // Piano
    virtualBand->muteInstrument(2, true);   // Bass
    virtualBand->muteInstrument(3, true);   // Guitar
    virtualBand->muteInstrument(10, false); // Drums (unmute)
    
    // Atualiza visual do botão
    drumPlayButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff00aa00));
    drumPauseButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff996600));
}

void MainComponent::drumPauseButtonClicked()
{
    if (!virtualBand)
        return;
    
    if (virtualBand->isDrumPlaying())
    {
        virtualBand->drumPause();
        drumPauseButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xffaa6600));
        drumPlayButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff0066aa));
    }
    else
    {
        virtualBand->drumPlay();
        drumPauseButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff996600));
        drumPlayButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff00aa00));
    }
}

void MainComponent::syncStartButtonClicked()
{
    if (!virtualBand)
        return;
    
    if (virtualBand->isSyncStartEnabled())
    {
        // Desabilita sync start
        virtualBand->syncStart(); // Toggle
        syncStartButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff663366));
        syncStartButton.setButtonText("SYNC");
    }
    else
    {
        // Habilita sync start
        virtualBand->syncStart(); // Toggle
        syncStartButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xffaa66aa));
        syncStartButton.setButtonText("SYNC ON");
    }
}

void MainComponent::tempoDownButtonClicked()
{
    int currentTempo = static_cast<int>(tempoSlider.getValue());
    tempoSlider.setValue(std::max(60, currentTempo - 1));
    tempoSliderChanged();
}

void MainComponent::tempoUpButtonClicked()
{
    int currentTempo = static_cast<int>(tempoSlider.getValue());
    tempoSlider.setValue(std::min(200, currentTempo + 1));
    tempoSliderChanged();
}

void MainComponent::tempoSliderChanged()
{
    int tempo = static_cast<int>(tempoSlider.getValue());
    
    if (virtualBand)
        virtualBand->setTempo(tempo);
        
    if (accompanimentGenerator)
        accompanimentGenerator->setTempo(tempo);
}

void MainComponent::midiInputChanged()
{
    if (!midiIO)
        return;
    
    int selectedId = midiInputCombo.getSelectedId();
    if (selectedId <= 1)
    {
        midiIO->closeMidiInput();
        return;
    }
    
    auto inputs = midiIO->getAvailableMidiInputs();
    int index = selectedId - 2;
    
    if (index >= 0 && index < inputs.size())
    {
        midiIO->setMidiInput(inputs[index]);
    }
}

void MainComponent::midiOutputChanged()
{
    if (!midiIO)
        return;
    
    int selectedId = midiOutputCombo.getSelectedId();
    if (selectedId <= 1)
    {
        midiIO->closeMidiOutput();
        return;
    }
    
    auto outputs = midiIO->getAvailableMidiOutputs();
    int index = selectedId - 2;
    
    if (index >= 0 && index < outputs.size())
    {
        midiIO->setMidiOutput(outputs[index]);
    }
}

void MainComponent::kontakt8ConnectButtonClicked()
{
    if (!kontakt8)
        return;
    
    if (kontakt8->isConnected())
    {
        kontakt8->disconnect();
        kontakt8ConnectButton.setButtonText("KONTAKT8");
    }
    else
    {
        kontakt8->initialize(midiIO.get());
        kontakt8ConnectButton.setButtonText("DISCONNECT");
    }
}

void MainComponent::chordChanged()
{
    if (!accompanimentGenerator)
        return;
    
    juce::String chord = chordCombo.getText();
    accompanimentGenerator->setChord(chord.toStdString());
}

void MainComponent::styleCategorySelected(int category)
{
    // Implementa seleção de categoria de estilo
}

void MainComponent::styleSelected(int style)
{
    // Implementa seleção de estilo
}

void MainComponent::variationSelected(StyleSectionType variation)
{
    if (!accompanimentGenerator)
        return;
    
    accompanimentGenerator->setSection(variation);
}

