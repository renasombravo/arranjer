#include "StyleParser.h"
#include <fstream>
#include <iostream>

StyleParser::StyleParser()
{
}

StyleParser::~StyleParser()
{
}

bool StyleParser::loadStyleFile(const std::string& filename)
{
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Erro ao abrir arquivo STY: " << filename << std::endl;
        return false;
    }

    // Lê cabeçalho do arquivo STY
    StyleHeader header;
    file.read(reinterpret_cast<char*>(&header), sizeof(StyleHeader));
    
    if (header.signature != 0x59545320) // "STY "
    {
        std::cerr << "Arquivo não é um STY válido" << std::endl;
        return false;
    }

    currentStyle.name = header.name;
    currentStyle.tempo = header.tempo;
    currentStyle.timeSignature = header.timeSignature;

    // Lê seções do estilo
    for (int i = 0; i < header.sectionCount; i++)
    {
        StyleSection section;
        file.read(reinterpret_cast<char*>(&section), sizeof(StyleSection));
        
        // Lê dados MIDI da seção
        std::vector<uint8_t> midiData(section.dataSize);
        file.read(reinterpret_cast<char*>(midiData.data()), section.dataSize);
        
        currentStyle.sections[section.type] = midiData;
    }

    file.close();
    return true;
}

const StyleData& StyleParser::getCurrentStyle() const
{
    return currentStyle;
}

std::vector<uint8_t> StyleParser::getSectionData(StyleSectionType type) const
{
    auto it = currentStyle.sections.find(type);
    if (it != currentStyle.sections.end())
    {
        return it->second;
    }
    return std::vector<uint8_t>();
}

void StyleParser::setTempo(int newTempo)
{
    currentStyle.tempo = newTempo;
}

void StyleParser::setTimeSignature(int numerator, int denominator)
{
    currentStyle.timeSignature = (numerator << 8) | denominator;
}

