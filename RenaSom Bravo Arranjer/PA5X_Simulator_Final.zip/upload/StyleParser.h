#pragma once

#include <string>
#include <vector>
#include <map>
#include <cstdint>

enum class StyleSectionType
{
    INTRO_A = 0,
    INTRO_B = 1,
    MAIN_A = 2,
    MAIN_B = 3,
    MAIN_C = 4,
    MAIN_D = 5,
    FILL_IN_AA = 6,
    FILL_IN_BB = 7,
    FILL_IN_CC = 8,
    FILL_IN_DD = 9,
    BREAK_FILL = 10,
    ENDING_A = 11,
    ENDING_B = 12,
    ENDING_C = 13
};

struct StyleHeader
{
    uint32_t signature;      // "STY "
    char name[32];           // Nome do estilo
    uint16_t tempo;          // BPM
    uint16_t timeSignature;  // Compasso (4/4, 3/4, etc)
    uint16_t sectionCount;   // Número de seções
    uint16_t reserved;
};

struct StyleSection
{
    uint8_t type;           // Tipo da seção
    uint8_t channel;        // Canal MIDI
    uint16_t dataSize;      // Tamanho dos dados MIDI
    uint32_t offset;        // Offset no arquivo
};

struct StyleData
{
    std::string name;
    int tempo;
    int timeSignature;
    std::map<StyleSectionType, std::vector<uint8_t>> sections;
};

class StyleParser
{
public:
    StyleParser();
    ~StyleParser();

    bool loadStyleFile(const std::string& filename);
    const StyleData& getCurrentStyle() const;
    std::vector<uint8_t> getSectionData(StyleSectionType type) const;
    
    void setTempo(int newTempo);
    void setTimeSignature(int numerator, int denominator);

private:
    StyleData currentStyle;
};

