#include "SoundFontLoader.h"
#include <fstream>
#include <iostream>

SoundFontLoader::SoundFontLoader()
    : isLoaded(false)
{
}

SoundFontLoader::~SoundFontLoader()
{
    unloadSoundFont();
}

bool SoundFontLoader::loadSoundFont(const std::string& filename)
{
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Erro ao abrir SoundFont: " << filename << std::endl;
        return false;
    }

    // Lê cabeçalho SF2
    SF2Header header;
    file.read(reinterpret_cast<char*>(&header), sizeof(SF2Header));
    
    if (header.riffSignature != 0x46464952 || // "RIFF"
        header.sf2Signature != 0x32666273)   // "sfbk"
    {
        std::cerr << "Arquivo não é um SoundFont válido" << std::endl;
        return false;
    }

    currentSoundFont.filename = filename;
    currentSoundFont.fileSize = header.fileSize;

    // Carrega presets
    loadPresets(file);
    
    // Carrega samples
    loadSamples(file);

    file.close();
    isLoaded = true;
    
    std::cout << "SoundFont carregado: " << filename << std::endl;
    std::cout << "Presets: " << currentSoundFont.presets.size() << std::endl;
    std::cout << "Samples: " << currentSoundFont.samples.size() << std::endl;
    
    return true;
}

void SoundFontLoader::unloadSoundFont()
{
    currentSoundFont.presets.clear();
    currentSoundFont.samples.clear();
    isLoaded = false;
}

bool SoundFontLoader::isLoaded() const
{
    return isLoaded;
}

const SoundFontData& SoundFontLoader::getSoundFontData() const
{
    return currentSoundFont;
}

std::vector<PresetInfo> SoundFontLoader::getPresetList() const
{
    std::vector<PresetInfo> presetList;
    
    for (const auto& preset : currentSoundFont.presets)
    {
        PresetInfo info;
        info.bank = preset.bank;
        info.program = preset.program;
        info.name = preset.name;
        presetList.push_back(info);
    }
    
    return presetList;
}

SampleData SoundFontLoader::getSample(int presetBank, int presetProgram, int note, int velocity)
{
    SampleData sampleData;
    
    if (!isLoaded)
        return sampleData;

    // Encontra o preset
    for (const auto& preset : currentSoundFont.presets)
    {
        if (preset.bank == presetBank && preset.program == presetProgram)
        {
            // Encontra o sample apropriado para a nota
            for (const auto& zone : preset.zones)
            {
                if (note >= zone.keyRangeLow && note <= zone.keyRangeHigh &&
                    velocity >= zone.velRangeLow && velocity <= zone.velRangeHigh)
                {
                    // Encontra o sample
                    if (zone.sampleIndex < currentSoundFont.samples.size())
                    {
                        sampleData = currentSoundFont.samples[zone.sampleIndex];
                        
                        // Aplica parâmetros da zona
                        sampleData.rootKey = zone.rootKey;
                        sampleData.fineTune = zone.fineTune;
                        sampleData.scaleTuning = zone.scaleTuning;
                        
                        return sampleData;
                    }
                }
            }
        }
    }
    
    return sampleData;
}

void SoundFontLoader::loadPresets(std::ifstream& file)
{
    // Implementação simplificada - em um SoundFont real seria muito mais complexo
    
    // Simula carregamento de alguns presets básicos
    SF2Preset preset1;
    preset1.bank = 0;
    preset1.program = 0;
    strcpy(preset1.name, "Acoustic Grand Piano");
    
    // Adiciona zona básica
    SF2Zone zone1;
    zone1.keyRangeLow = 0;
    zone1.keyRangeHigh = 127;
    zone1.velRangeLow = 0;
    zone1.velRangeHigh = 127;
    zone1.sampleIndex = 0;
    zone1.rootKey = 60; // C4
    zone1.fineTune = 0;
    zone1.scaleTuning = 100;
    
    preset1.zones.push_back(zone1);
    currentSoundFont.presets.push_back(preset1);
    
    // Adiciona mais presets
    SF2Preset preset2;
    preset2.bank = 0;
    preset2.program = 1;
    strcpy(preset2.name, "Bright Acoustic Piano");
    preset2.zones.push_back(zone1);
    currentSoundFont.presets.push_back(preset2);
    
    SF2Preset preset3;
    preset3.bank = 0;
    preset3.program = 24;
    strcpy(preset3.name, "Acoustic Guitar (nylon)");
    preset3.zones.push_back(zone1);
    currentSoundFont.presets.push_back(preset3);
    
    SF2Preset preset4;
    preset4.bank = 0;
    preset4.program = 32;
    strcpy(preset4.name, "Acoustic Bass");
    preset4.zones.push_back(zone1);
    currentSoundFont.presets.push_back(preset4);
}

void SoundFontLoader::loadSamples(std::ifstream& file)
{
    // Implementação simplificada - cria samples dummy
    
    SampleData sample1;
    sample1.name = "Piano Sample";
    sample1.sampleRate = 44100;
    sample1.rootKey = 60;
    sample1.fineTune = 0;
    sample1.scaleTuning = 100;
    sample1.loopStart = 0;
    sample1.loopEnd = 1000;
    sample1.isLooped = false;
    
    // Gera dados de sample sintético (onda senoidal)
    int sampleLength = 44100; // 1 segundo
    sample1.audioData.resize(sampleLength);
    
    for (int i = 0; i < sampleLength; i++)
    {
        float t = static_cast<float>(i) / 44100.0f;
        float frequency = 440.0f; // A4
        float amplitude = 0.5f * exp(-t * 2.0f); // Decay exponencial
        sample1.audioData[i] = amplitude * sin(2.0f * M_PI * frequency * t);
    }
    
    currentSoundFont.samples.push_back(sample1);
}

