#include "Effects.h"
#include <cmath>
#include <algorithm>

//==============================================================================
// Reverb Effect
//==============================================================================

ReverbEffect::ReverbEffect()
    : roomSize(0.5f)
    , damping(0.5f)
    , wetLevel(0.3f)
    , dryLevel(0.7f)
    , width(1.0f)
    , freezeMode(false)
{
    // Inicializa parâmetros do reverb
    juce::Reverb::Parameters params;
    params.roomSize = roomSize;
    params.damping = damping;
    params.wetLevel = wetLevel;
    params.dryLevel = dryLevel;
    params.width = width;
    params.freezeMode = freezeMode;
    
    reverb.setParameters(params);
}

void ReverbEffect::processAudio(juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumChannels() == 1)
    {
        // Mono para stereo
        juce::AudioBuffer<float> stereoBuffer(2, buffer.getNumSamples());
        stereoBuffer.copyFrom(0, 0, buffer, 0, 0, buffer.getNumSamples());
        stereoBuffer.copyFrom(1, 0, buffer, 0, 0, buffer.getNumSamples());
        
        reverb.processStereo(stereoBuffer.getWritePointer(0), 
                           stereoBuffer.getWritePointer(1), 
                           buffer.getNumSamples());
        
        // Copia de volta para mono
        buffer.copyFrom(0, 0, stereoBuffer, 0, 0, buffer.getNumSamples());
    }
    else if (buffer.getNumChannels() >= 2)
    {
        reverb.processStereo(buffer.getWritePointer(0), 
                           buffer.getWritePointer(1), 
                           buffer.getNumSamples());
    }
}

void ReverbEffect::setRoomSize(float size)
{
    roomSize = std::clamp(size, 0.0f, 1.0f);
    updateParameters();
}

void ReverbEffect::setDamping(float damp)
{
    damping = std::clamp(damp, 0.0f, 1.0f);
    updateParameters();
}

void ReverbEffect::setWetLevel(float wet)
{
    wetLevel = std::clamp(wet, 0.0f, 1.0f);
    updateParameters();
}

void ReverbEffect::setDryLevel(float dry)
{
    dryLevel = std::clamp(dry, 0.0f, 1.0f);
    updateParameters();
}

void ReverbEffect::updateParameters()
{
    juce::Reverb::Parameters params;
    params.roomSize = roomSize;
    params.damping = damping;
    params.wetLevel = wetLevel;
    params.dryLevel = dryLevel;
    params.width = width;
    params.freezeMode = freezeMode;
    
    reverb.setParameters(params);
}

//==============================================================================
// Chorus Effect
//==============================================================================

ChorusEffect::ChorusEffect()
    : rate(1.0f)
    , depth(0.25f)
    , centreDelay(7.0f)
    , feedback(0.0f)
    , mix(0.5f)
    , sampleRate(44100.0)
{
    delayBuffer.setSize(2, static_cast<int>(sampleRate * 0.1)); // 100ms max delay
    delayBuffer.clear();
    
    lfoPhase = 0.0f;
    writePosition = 0;
}

void ChorusEffect::prepare(double newSampleRate, int samplesPerBlock)
{
    sampleRate = newSampleRate;
    delayBuffer.setSize(2, static_cast<int>(sampleRate * 0.1));
    delayBuffer.clear();
    writePosition = 0;
}

void ChorusEffect::processAudio(juce::AudioBuffer<float>& buffer)
{
    int numChannels = buffer.getNumChannels();
    int numSamples = buffer.getNumSamples();
    
    for (int channel = 0; channel < numChannels; channel++)
    {
        float* channelData = buffer.getWritePointer(channel);
        float* delayData = delayBuffer.getWritePointer(channel % delayBuffer.getNumChannels());
        
        for (int sample = 0; sample < numSamples; sample++)
        {
            // Calcula delay variável usando LFO
            float lfo = std::sin(lfoPhase) * depth;
            float delayTime = (centreDelay + lfo) * 0.001f; // ms para segundos
            float delaySamples = delayTime * static_cast<float>(sampleRate);
            
            // Calcula posição de leitura
            float readPosition = writePosition - delaySamples;
            if (readPosition < 0)
                readPosition += delayBuffer.getNumSamples();
            
            // Interpolação linear
            int readPos1 = static_cast<int>(readPosition);
            int readPos2 = (readPos1 + 1) % delayBuffer.getNumSamples();
            float fraction = readPosition - readPos1;
            
            float delayedSample = delayData[readPos1] * (1.0f - fraction) + 
                                delayData[readPos2] * fraction;
            
            // Aplica feedback
            float input = channelData[sample];
            float output = input + delayedSample * feedback;
            
            // Escreve no buffer de delay
            delayData[writePosition] = output;
            
            // Mix wet/dry
            channelData[sample] = input * (1.0f - mix) + delayedSample * mix;
            
            // Atualiza LFO
            lfoPhase += 2.0f * M_PI * rate / static_cast<float>(sampleRate);
            if (lfoPhase >= 2.0f * M_PI)
                lfoPhase -= 2.0f * M_PI;
            
            // Atualiza posição de escrita
            writePosition = (writePosition + 1) % delayBuffer.getNumSamples();
        }
    }
}

void ChorusEffect::setRate(float newRate)
{
    rate = std::clamp(newRate, 0.1f, 10.0f);
}

void ChorusEffect::setDepth(float newDepth)
{
    depth = std::clamp(newDepth, 0.0f, 1.0f);
}

void ChorusEffect::setCentreDelay(float newDelay)
{
    centreDelay = std::clamp(newDelay, 1.0f, 50.0f);
}

void ChorusEffect::setFeedback(float newFeedback)
{
    feedback = std::clamp(newFeedback, -0.95f, 0.95f);
}

void ChorusEffect::setMix(float newMix)
{
    mix = std::clamp(newMix, 0.0f, 1.0f);
}

//==============================================================================
// Effects Processor
//==============================================================================

EffectsProcessor::EffectsProcessor()
    : reverbEnabled(false)
    , chorusEnabled(false)
{
}

void EffectsProcessor::prepare(double sampleRate, int samplesPerBlock)
{
    chorusEffect.prepare(sampleRate, samplesPerBlock);
}

void EffectsProcessor::processAudio(juce::AudioBuffer<float>& buffer)
{
    if (chorusEnabled)
    {
        chorusEffect.processAudio(buffer);
    }
    
    if (reverbEnabled)
    {
        reverbEffect.processAudio(buffer);
    }
}

void EffectsProcessor::enableReverb(bool enable)
{
    reverbEnabled = enable;
}

void EffectsProcessor::enableChorus(bool enable)
{
    chorusEnabled = enable;
}

ReverbEffect& EffectsProcessor::getReverb()
{
    return reverbEffect;
}

ChorusEffect& EffectsProcessor::getChorus()
{
    return chorusEffect;
}

