#include "Kontakt8Integration.h"

Kontakt8Integration::Kontakt8Integration()
    : isConnected(false)
    , kontaktChannel(1)
    , isKontaktLoaded(false)
{
}

Kontakt8Integration::~Kontakt8Integration()
{
    disconnect();
}

bool Kontakt8Integration::initialize(MidiIO* midiIO)
{
    this->midiIO = midiIO;
    
    if (!midiIO)
        return false;
    
    // Cria porta virtual específica para Kontakt8
    if (!midiIO->hasVirtualMidiPort())
    {
        if (!midiIO->createVirtualMidiPort("ArrangerSimulator_To_Kontakt8"))
        {
            DBG("Failed to create virtual MIDI port for Kontakt8");
            return false;
        }
    }
    
    // Detecta se Kontakt8 está disponível
    detectKontakt8();
    
    // Carrega configuração padrão
    loadDefaultConfiguration();
    
    isConnected = true;
    DBG("Kontakt8 integration initialized");
    
    return true;
}

void Kontakt8Integration::disconnect()
{
    if (midiIO && midiIO->hasVirtualMidiPort())
    {
        // Envia All Notes Off para todos os canais
        for (int ch = 1; ch <= 16; ch++)
        {
            sendAllNotesOff(ch);
        }
        
        midiIO->closeVirtualMidiPort();
    }
    
    isConnected = false;
    isKontaktLoaded = false;
    DBG("Kontakt8 integration disconnected");
}

bool Kontakt8Integration::loadInstrument(int channel, const juce::String& instrumentPath, const juce::String& instrumentName)
{
    if (!isConnected || !midiIO)
        return false;
    
    // Cria entrada para o instrumento
    KontaktInstrument instrument;
    instrument.channel = channel;
    instrument.name = instrumentName;
    instrument.path = instrumentPath;
    instrument.isLoaded = false;
    instrument.bank = 0;
    instrument.program = 0;
    
    // Para Kontakt8, usamos SysEx para carregar instrumentos
    // Isso é uma implementação simplificada - o protocolo real seria mais complexo
    std::vector<uint8_t> sysexData = createLoadInstrumentSysEx(channel, instrumentPath);
    
    if (!sysexData.empty())
    {
        juce::MidiMessage sysexMessage = juce::MidiMessage::createSysExMessage(sysexData.data(), sysexData.size());
        midiIO->sendMidiMessage(sysexMessage);
        
        instrument.isLoaded = true;
        kontaktInstruments[channel] = instrument;
        
        DBG("Loaded Kontakt8 instrument: " << instrumentName << " on channel " << channel);
        return true;
    }
    
    return false;
}

void Kontakt8Integration::unloadInstrument(int channel)
{
    auto it = kontaktInstruments.find(channel);
    if (it != kontaktInstruments.end())
    {
        // Envia All Notes Off para o canal
        sendAllNotesOff(channel);
        
        // Remove da lista
        kontaktInstruments.erase(it);
        
        DBG("Unloaded Kontakt8 instrument from channel " << channel);
    }
}

void Kontakt8Integration::setInstrumentParameter(int channel, int parameterId, float value)
{
    auto it = kontaktInstruments.find(channel);
    if (it != kontaktInstruments.end() && midiIO)
    {
        // Converte para MIDI CC ou NRPN dependendo do parâmetro
        if (parameterId < 128)
        {
            // CC padrão
            int ccValue = static_cast<int>(value * 127);
            juce::MidiMessage cc = juce::MidiMessage::controllerEvent(channel, parameterId, ccValue);
            midiIO->sendMidiMessage(cc);
        }
        else
        {
            // NRPN para parâmetros estendidos
            sendNRPN(channel, parameterId, static_cast<int>(value * 16383));
        }
        
        DBG("Set Kontakt8 parameter - Ch:" << channel << " Param:" << parameterId << " Value:" << value);
    }
}

void Kontakt8Integration::sendProgramChange(int channel, int bank, int program)
{
    if (!isConnected || !midiIO)
        return;
    
    // Bank Select MSB
    juce::MidiMessage bankMSB = juce::MidiMessage::controllerEvent(channel, 0, bank >> 7);
    midiIO->sendMidiMessage(bankMSB);
    
    // Bank Select LSB
    juce::MidiMessage bankLSB = juce::MidiMessage::controllerEvent(channel, 32, bank & 0x7F);
    midiIO->sendMidiMessage(bankLSB);
    
    // Program Change
    juce::MidiMessage pc = juce::MidiMessage::programChange(channel, program);
    midiIO->sendMidiMessage(pc);
    
    // Atualiza instrumento se existir
    auto it = kontaktInstruments.find(channel);
    if (it != kontaktInstruments.end())
    {
        it->second.bank = bank;
        it->second.program = program;
    }
    
    DBG("Sent program change to Kontakt8 - Ch:" << channel << " Bank:" << bank << " Program:" << program);
}

void Kontakt8Integration::sendControlChange(int channel, int controller, int value)
{
    if (!isConnected || !midiIO)
        return;
    
    juce::MidiMessage cc = juce::MidiMessage::controllerEvent(channel, controller, value);
    midiIO->sendMidiMessage(cc);
    
    DBG("Sent CC to Kontakt8 - Ch:" << channel << " CC:" << controller << " Value:" << value);
}

void Kontakt8Integration::sendAllNotesOff(int channel)
{
    if (!isConnected || !midiIO)
        return;
    
    // All Notes Off (CC 123)
    juce::MidiMessage allNotesOff = juce::MidiMessage::controllerEvent(channel, 123, 0);
    midiIO->sendMidiMessage(allNotesOff);
    
    // All Sound Off (CC 120) como backup
    juce::MidiMessage allSoundOff = juce::MidiMessage::controllerEvent(channel, 120, 0);
    midiIO->sendMidiMessage(allSoundOff);
    
    DBG("Sent All Notes Off to Kontakt8 channel " << channel);
}

void Kontakt8Integration::sendPanic()
{
    if (!isConnected)
        return;
    
    // Envia All Notes Off para todos os canais
    for (int ch = 1; ch <= 16; ch++)
    {
        sendAllNotesOff(ch);
    }
    
    DBG("Sent panic to Kontakt8");
}

std::vector<KontaktInstrument> Kontakt8Integration::getLoadedInstruments() const
{
    std::vector<KontaktInstrument> result;
    for (const auto& pair : kontaktInstruments)
    {
        result.push_back(pair.second);
    }
    return result;
}

KontaktInstrument* Kontakt8Integration::getInstrument(int channel)
{
    auto it = kontaktInstruments.find(channel);
    return (it != kontaktInstruments.end()) ? &it->second : nullptr;
}

bool Kontakt8Integration::isInstrumentLoaded(int channel) const
{
    auto it = kontaktInstruments.find(channel);
    return it != kontaktInstruments.end() && it->second.isLoaded;
}

void Kontakt8Integration::setMasterVolume(float volume)
{
    if (!isConnected || !midiIO)
        return;
    
    // Envia Master Volume SysEx
    std::vector<uint8_t> sysexData = {
        0xF0, 0x7F, 0x7F, 0x04, 0x01, // Universal SysEx Master Volume
        0x00, static_cast<uint8_t>(volume * 127), // LSB, MSB
        0xF7
    };
    
    juce::MidiMessage sysex = juce::MidiMessage::createSysExMessage(sysexData.data(), sysexData.size());
    midiIO->sendMidiMessage(sysex);
    
    DBG("Set Kontakt8 master volume: " << volume);
}

void Kontakt8Integration::detectKontakt8()
{
    // Verifica se Kontakt8 está rodando
    // Em uma implementação real, isso verificaria processos do sistema
    // ou tentaria conectar via protocolo específico do Kontakt
    
    // Por enquanto, assume que está disponível se conseguiu criar a porta virtual
    if (midiIO && midiIO->hasVirtualMidiPort())
    {
        isKontaktLoaded = true;
        DBG("Kontakt8 detected and available");
    }
    else
    {
        isKontaktLoaded = false;
        DBG("Kontakt8 not detected");
    }
}

void Kontakt8Integration::loadDefaultConfiguration()
{
    // Carrega configuração padrão de instrumentos
    defaultInstruments.clear();
    
    // Piano
    KontaktInstrument piano;
    piano.channel = 1;
    piano.name = "Kontakt Piano";
    piano.path = "Factory/Piano/Grand Piano.nki";
    piano.bank = 0;
    piano.program = 0;
    piano.isLoaded = false;
    defaultInstruments.push_back(piano);
    
    // Bass
    KontaktInstrument bass;
    bass.channel = 2;
    bass.name = "Kontakt Bass";
    bass.path = "Factory/Bass/Electric Bass.nki";
    bass.bank = 0;
    bass.program = 32;
    bass.isLoaded = false;
    defaultInstruments.push_back(bass);
    
    // Drums
    KontaktInstrument drums;
    drums.channel = 10;
    drums.name = "Kontakt Drums";
    drums.path = "Factory/Drums/Studio Drums.nki";
    drums.bank = 128;
    drums.program = 0;
    drums.isLoaded = false;
    defaultInstruments.push_back(drums);
    
    // Guitar
    KontaktInstrument guitar;
    guitar.channel = 3;
    guitar.name = "Kontakt Guitar";
    guitar.path = "Factory/Guitar/Acoustic Guitar.nki";
    guitar.bank = 0;
    guitar.program = 24;
    guitar.isLoaded = false;
    defaultInstruments.push_back(guitar);
    
    DBG("Default Kontakt8 configuration loaded");
}

std::vector<uint8_t> Kontakt8Integration::createLoadInstrumentSysEx(int channel, const juce::String& instrumentPath)
{
    // Cria mensagem SysEx para carregar instrumento no Kontakt8
    // Isso é uma implementação simplificada - o protocolo real seria específico do Kontakt
    
    std::vector<uint8_t> sysex;
    sysex.push_back(0xF0); // SysEx start
    sysex.push_back(0x17); // Native Instruments ID (hipotético)
    sysex.push_back(0x00); // Kontakt8 ID
    sysex.push_back(0x01); // Load Instrument command
    sysex.push_back(static_cast<uint8_t>(channel)); // Channel
    
    // Adiciona path do instrumento (simplificado)
    juce::String pathBytes = instrumentPath;
    for (int i = 0; i < pathBytes.length() && i < 100; i++)
    {
        uint8_t byte = static_cast<uint8_t>(pathBytes[i]);
        if (byte < 128) // Apenas bytes válidos para SysEx
            sysex.push_back(byte);
    }
    
    sysex.push_back(0x00); // String terminator
    sysex.push_back(0xF7); // SysEx end
    
    return sysex;
}

void Kontakt8Integration::sendNRPN(int channel, int parameter, int value)
{
    if (!midiIO)
        return;
    
    // NRPN MSB
    juce::MidiMessage nrpnMSB = juce::MidiMessage::controllerEvent(channel, 99, (parameter >> 7) & 0x7F);
    midiIO->sendMidiMessage(nrpnMSB);
    
    // NRPN LSB
    juce::MidiMessage nrpnLSB = juce::MidiMessage::controllerEvent(channel, 98, parameter & 0x7F);
    midiIO->sendMidiMessage(nrpnLSB);
    
    // Data Entry MSB
    juce::MidiMessage dataMSB = juce::MidiMessage::controllerEvent(channel, 6, (value >> 7) & 0x7F);
    midiIO->sendMidiMessage(dataMSB);
    
    // Data Entry LSB
    juce::MidiMessage dataLSB = juce::MidiMessage::controllerEvent(channel, 38, value & 0x7F);
    midiIO->sendMidiMessage(dataLSB);
    
    DBG("Sent NRPN to Kontakt8 - Ch:" << channel << " Param:" << parameter << " Value:" << value);
}

