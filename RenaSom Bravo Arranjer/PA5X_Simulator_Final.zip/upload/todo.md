## Tarefas

- [x] **Fase 1: Pesquisar e analisar requisitos técnicos**
- [x] **Fase 2: Analisar formato de arquivo STY e bibliotecas MIDI**
- [x] **Fase 3: Projetar arquitetura do software**
- [ ] **Fase 4: Implementar motor de áudio e MIDI**
  - [x] Configurar ambiente de desenvolvimento C++/JUCE.
  - [x] Implementar I/O de áudio (ASIO/WASAPI/CoreAudio) e MIDI (multi-port).
  - [x] Desenvolver o Scheduler Tempo/Clock.
  - [ ] Implementar o mixer básico e efeitos (Reverb/Chorus).
  - [x] Criar protótipo básico do Chord Engine.
  - [ ] Implementar carregador básico de SF2/SFZ.
  - [ ] Testar latência e performance do motor de áudio.

- [ ] **Fase 5: Criar interface gráfica do usuário**
  - [ ] Desenvolver a janela principal (transport, seções, teclado visual, mixer, browser de estilos/sons, setlist).
  - [ ] Criar páginas de mapeamento MIDI Learn e preferências.

- [ ] **Fase 6: Integrar componentes e testes**
  - [ ] Integrar o Style Engine, Sound Engine/Host e UI.
  - [ ] Realizar testes unitários e de carga.
  - [ ] Otimizar para baixa latência e estabilidade.

- [ ] **Fase 7: Entregar software funcional ao usuário**
  - [ ] Gerar executável e instalador para Windows.
  - [ ] Preparar código-fonte e documentação.
  - [ ] Criar estilos de demonstração e banco SF2/SFZ livre.

