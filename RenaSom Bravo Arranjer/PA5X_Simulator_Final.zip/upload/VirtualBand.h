#pragma once

#include <JuceHeader.h>
#include "MidiIO.h"
#include "../SoundEngine/SoundFontLoader.h"
#include <map>
#include <vector>
#include <algorithm>
#include <atomic>
#include <mutex>

struct VirtualInstrument
{
    int channel;
    juce::String name;
    int bank;
    int program;
    std::atomic<float> volume;
    std::atomic<float> pan;
    std::atomic<bool> muted;
    std::atomic<bool> solo;
    bool isKontakt8Instrument;
    bool isDrumKit;
    
    VirtualInstrument()
        : channel(1), bank(0), program(0), volume(1.0f), pan(0.0f)
        , muted(false), solo(false), isKontakt8Instrument(false), isDrumKit(false) {}
};

struct ActiveNote
{
    int channel;
    int note;
    int velocity;
    double startTime;
    int voiceId;
    bool active;
};

/**
 * VirtualBand - Enhanced virtual band with rhythm controls and drum play/pause
 * Supports 240 voice polyphony and advanced rhythm management
 */
class VirtualBand
{
public:
    VirtualBand();
    ~VirtualBand();

    // Inicialização
    void initialize(MidiIO* midiIO, SoundFontLoader* soundFontLoader);
    
    // Gerenciamento de instrumentos
    void addInstrument(const VirtualInstrument& instrument);
    void removeInstrument(int channel);
    void setInstrumentProgram(int channel, int bank, int program);
    void setInstrumentVolume(int channel, float volume);
    void setInstrumentPan(int channel, float pan);
    void muteInstrument(int channel, bool mute);
    void soloInstrument(int channel, bool solo);
    
    // Controle de reprodução
    void playNote(int channel, int note, int velocity);
    void stopNote(int channel, int note);
    void stopAllNotes();
    void stopAllNotesOnChannel(int channel);
    
    // Controles de ritmo estilo PA5X
    void start();
    void stop();
    void pause();
    void resume();
    void syncStart();
    void drumPlay();
    void drumPause();
    void drumStop();
    
    // Controles de tempo e ritmo
    void setTempo(int tempo);
    void setMasterVolume(float volume);
    void setSwing(float swing);
    void setQuantization(int quantize);
    
    // Configuração de polifonia
    void setMaxPolyphony(int voices);
    
    // Estado dos controles de ritmo
    bool isRhythmPlaying() const { return rhythmPlaying.load(); }
    bool isDrumPlaying() const { return drumPlaying.load(); }
    bool isPaused() const { return paused.load(); }
    bool isSyncStartEnabled() const { return syncStartEnabled.load(); }
    
    // Getters
    std::vector<VirtualInstrument> getInstruments() const;
    VirtualInstrument* getInstrument(int channel);
    bool isInstrumentActive(int channel) const;
    bool isPlaying() const { return playing.load(); }
    int getTempo() const { return currentTempo.load(); }
    float getMasterVolume() const { return masterVolume.load(); }
    int getActiveVoices() const { return activeVoices.load(); }
    int getMaxPolyphony() const { return maxPolyphony.load(); }

private:
    // Callbacks MIDI
    void handleNoteOn(int channel, int note, int velocity);
    void handleNoteOff(int channel, int note, int velocity);
    void handleControlChange(int channel, int controller, int value);
    
    // Inicialização
    void initializeDefaultInstruments();
    void setupDrumKit();
    
    // Gerenciamento de vozes
    int allocateVoice(int channel, int note);
    void releaseVoice(int voiceId);
    void cleanupInactiveVoices();
    
    // Membros thread-safe
    std::map<int, VirtualInstrument> instruments;
    std::vector<ActiveNote> activeNotes;
    mutable std::mutex instrumentsMutex;
    mutable std::mutex notesMutex;
    
    MidiIO* midiIO;
    SoundFontLoader* soundFontLoader;
    
    // Estado de reprodução
    std::atomic<bool> playing;
    std::atomic<bool> rhythmPlaying;
    std::atomic<bool> drumPlaying;
    std::atomic<bool> paused;
    std::atomic<bool> syncStartEnabled;
    
    // Configurações
    std::atomic<int> currentTempo;
    std::atomic<float> masterVolume;
    std::atomic<float> swing;
    std::atomic<int> quantization;
    std::atomic<int> maxPolyphony;
    std::atomic<int> activeVoices;
    
    // Canais especiais
    static const int DRUM_CHANNEL = 10;
    static const int RHYTHM_CHANNEL = 11;
    static const int BASS_CHANNEL = 12;
    static const int CHORD_CHANNEL = 13;
};

