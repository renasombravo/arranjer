#include "AudioEngine_Standalone.h"
#include <iostream>
#include <chrono>
#include <algorithm>

#ifdef __linux__
#include <alsa/asoundlib.h>
#endif

AudioEngineStandalone::AudioEngineStandalone()
    : sampleRate(44100.0)
    , bufferSize(512)
    , maxPolyphony(240)
    , initialized(false)
    , cpuUsage(0.0)
    , shouldStop(false)
#ifdef __linux__
    , alsaHandle(nullptr)
#endif
{
}

AudioEngineStandalone::~AudioEngineStandalone()
{
    releaseResources();
}

bool AudioEngineStandalone::initialize()
{
    if (initialized.load())
        return true;
    
    // Inicializa buffer de mix
    mixBuffer = std::make_unique<StandaloneAudioBuffer>(2, bufferSize.load());
    
    // Inicializa dispositivo de áudio
    if (!initializeAudioDevice())
    {
        std::cerr << "Failed to initialize audio device" << std::endl;
        return false;
    }
    
    // Inicia thread de áudio
    shouldStop = false;
    audioThread = std::thread(&AudioEngineStandalone::audioThreadFunction, this);
    
    initialized = true;
    std::cout << "AudioEngine initialized - Sample Rate: " << sampleRate.load() 
              << " Hz, Buffer Size: " << bufferSize.load() << " samples" << std::endl;
    
    return true;
}

void AudioEngineStandalone::prepareToPlay(int samplesPerBlockExpected, double newSampleRate)
{
    bufferSize = samplesPerBlockExpected;
    sampleRate = newSampleRate;
    
    // Recria buffer de mix com novo tamanho
    mixBuffer = std::make_unique<StandaloneAudioBuffer>(2, bufferSize.load());
    
    std::cout << "AudioEngine prepared - Sample Rate: " << sampleRate.load() 
              << " Hz, Buffer Size: " << bufferSize.load() << " samples" << std::endl;
}

void AudioEngineStandalone::getNextAudioBlock(const StandaloneAudioSourceChannelInfo& bufferToFill)
{
    processAudioBlock(bufferToFill);
}

void AudioEngineStandalone::releaseResources()
{
    if (!initialized.load())
        return;
    
    // Para thread de áudio
    shouldStop = true;
    if (audioThread.joinable())
    {
        audioThread.join();
    }
    
    // Fecha dispositivo de áudio
#ifdef __linux__
    closeALSA();
#endif
    
    // Limpa recursos
    removeAllAudioSources();
    mixBuffer.reset();
    
    initialized = false;
    std::cout << "AudioEngine resources released" << std::endl;
}

void AudioEngineStandalone::processAudioBlock(const StandaloneAudioSourceChannelInfo& bufferToFill)
{
    auto startTime = std::chrono::high_resolution_clock::now();
    
    if (!bufferToFill.buffer)
        return;
    
    // Limpa buffer de saída
    bufferToFill.clearActiveBufferRegion();
    
    // Mixa todas as fontes de áudio
    mixAudioSources(*bufferToFill.buffer);
    
    // Aplica efeitos master
    applyMasterEffects(*bufferToFill.buffer);
    
    // Calcula uso de CPU
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);
    double blockTimeMs = (bufferSize.load() * 1000.0) / sampleRate.load();
    cpuUsage = (duration.count() / 1000.0) / blockTimeMs * 100.0;
}

void AudioEngineStandalone::addAudioSource(std::function<void(StandaloneAudioBuffer&)> source)
{
    std::lock_guard<std::mutex> lock(audioSourcesMutex);
    audioSources.push_back(source);
}

void AudioEngineStandalone::removeAllAudioSources()
{
    std::lock_guard<std::mutex> lock(audioSourcesMutex);
    audioSources.clear();
}

void AudioEngineStandalone::setMaxPolyphony(int voices)
{
    maxPolyphony = std::clamp(voices, 1, 512);
    std::cout << "Max polyphony set to: " << maxPolyphony.load() << " voices" << std::endl;
}

void AudioEngineStandalone::setBufferSize(int samples)
{
    bufferSize = std::clamp(samples, 64, 4096);
    
    // Recria buffer de mix
    if (initialized.load())
    {
        mixBuffer = std::make_unique<StandaloneAudioBuffer>(2, bufferSize.load());
    }
    
    std::cout << "Buffer size set to: " << bufferSize.load() << " samples" << std::endl;
}

void AudioEngineStandalone::setSampleRate(double rate)
{
    sampleRate = std::clamp(rate, 22050.0, 192000.0);
    std::cout << "Sample rate set to: " << sampleRate.load() << " Hz" << std::endl;
}

bool AudioEngineStandalone::initializeAudioDevice()
{
#ifdef __linux__
    return initializeALSA();
#else
    // Para outras plataformas, simula sucesso
    std::cout << "Audio device simulation initialized" << std::endl;
    return true;
#endif
}

std::vector<std::string> AudioEngineStandalone::getAvailableAudioDevices()
{
    std::vector<std::string> devices;
    
#ifdef __linux__
    // Lista dispositivos ALSA
    void** hints;
    if (snd_device_name_hint(-1, "pcm", &hints) == 0)
    {
        void** hint = hints;
        while (*hint)
        {
            char* name = snd_device_name_get_hint(*hint, "NAME");
            if (name)
            {
                devices.push_back(std::string(name));
                free(name);
            }
            hint++;
        }
        snd_device_name_free_hint(hints);
    }
#endif
    
    // Adiciona dispositivo padrão se lista estiver vazia
    if (devices.empty())
    {
        devices.push_back("default");
    }
    
    return devices;
}

bool AudioEngineStandalone::setAudioDevice(const std::string& deviceName)
{
    std::cout << "Setting audio device to: " << deviceName << std::endl;
    
#ifdef __linux__
    closeALSA();
    return initializeALSA();
#else
    return true;
#endif
}

void AudioEngineStandalone::audioThreadFunction()
{
    std::cout << "Audio thread started" << std::endl;
    
    const int blockSize = bufferSize.load();
    const double sampleRateLocal = sampleRate.load();
    const auto blockDuration = std::chrono::microseconds(
        static_cast<long>((blockSize * 1000000.0) / sampleRateLocal)
    );
    
    StandaloneAudioBuffer audioBuffer(2, blockSize);
    StandaloneAudioSourceChannelInfo channelInfo;
    channelInfo.buffer = &audioBuffer;
    channelInfo.startSample = 0;
    channelInfo.numSamples = blockSize;
    
    while (!shouldStop.load())
    {
        auto blockStart = std::chrono::high_resolution_clock::now();
        
        // Processa bloco de áudio
        processAudioBlock(channelInfo);
        
        // Simula saída de áudio (em implementação real, enviaria para ALSA/PulseAudio)
        
        // Espera até o próximo bloco
        auto blockEnd = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(blockEnd - blockStart);
        
        if (elapsed < blockDuration)
        {
            std::this_thread::sleep_for(blockDuration - elapsed);
        }
    }
    
    std::cout << "Audio thread stopped" << std::endl;
}

void AudioEngineStandalone::mixAudioSources(StandaloneAudioBuffer& outputBuffer)
{
    std::lock_guard<std::mutex> lock(audioSourcesMutex);
    
    // Limpa buffer de mix
    if (mixBuffer)
        mixBuffer->clear();
    
    // Processa cada fonte de áudio
    for (auto& source : audioSources)
    {
        if (source && mixBuffer)
        {
            source(*mixBuffer);
            
            // Adiciona ao buffer de saída
            for (int ch = 0; ch < std::min(outputBuffer.numChannels, mixBuffer->numChannels); ch++)
            {
                for (int sample = 0; sample < std::min(outputBuffer.numSamples, mixBuffer->numSamples); sample++)
                {
                    outputBuffer.addSample(ch, sample, mixBuffer->channels[ch][sample]);
                }
            }
        }
    }
}

void AudioEngineStandalone::applyMasterEffects(StandaloneAudioBuffer& buffer)
{
    // Aplica limitador simples para evitar clipping
    const float threshold = 0.95f;
    
    for (int ch = 0; ch < buffer.numChannels; ch++)
    {
        for (int sample = 0; sample < buffer.numSamples; sample++)
        {
            float& value = buffer.channels[ch][sample];
            
            // Limitador soft
            if (value > threshold)
                value = threshold + (value - threshold) * 0.1f;
            else if (value < -threshold)
                value = -threshold + (value + threshold) * 0.1f;
            
            // Clamp final
            value = std::clamp(value, -1.0f, 1.0f);
        }
    }
}

#ifdef __linux__
bool AudioEngineStandalone::initializeALSA()
{
    snd_pcm_t* pcm;
    int err;
    
    // Abre dispositivo PCM
    err = snd_pcm_open(&pcm, "default", SND_PCM_STREAM_PLAYBACK, 0);
    if (err < 0)
    {
        std::cerr << "Cannot open PCM device: " << snd_strerror(err) << std::endl;
        return false;
    }
    
    // Configura parâmetros
    snd_pcm_hw_params_t* params;
    snd_pcm_hw_params_alloca(&params);
    snd_pcm_hw_params_any(pcm, params);
    
    // Formato
    snd_pcm_hw_params_set_access(pcm, params, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(pcm, params, SND_PCM_FORMAT_FLOAT_LE);
    snd_pcm_hw_params_set_channels(pcm, params, 2);
    
    // Sample rate
    unsigned int rate = static_cast<unsigned int>(sampleRate.load());
    snd_pcm_hw_params_set_rate_near(pcm, params, &rate, 0);
    
    // Buffer size
    snd_pcm_uframes_t frames = bufferSize.load();
    snd_pcm_hw_params_set_period_size_near(pcm, params, &frames, 0);
    
    // Aplica parâmetros
    err = snd_pcm_hw_params(pcm, params);
    if (err < 0)
    {
        std::cerr << "Cannot set PCM parameters: " << snd_strerror(err) << std::endl;
        snd_pcm_close(pcm);
        return false;
    }
    
    alsaHandle = pcm;
    std::cout << "ALSA initialized successfully" << std::endl;
    return true;
}

void AudioEngineStandalone::closeALSA()
{
    if (alsaHandle)
    {
        snd_pcm_close(static_cast<snd_pcm_t*>(alsaHandle));
        alsaHandle = nullptr;
        std::cout << "ALSA closed" << std::endl;
    }
}
#endif

