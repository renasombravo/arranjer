#pragma once

#include <JuceHeader.h>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

//==============================================================================
// Reverb Effect
//==============================================================================

class ReverbEffect
{
public:
    ReverbEffect();
    
    void processAudio(juce::AudioBuffer<float>& buffer);
    
    void setRoomSize(float size);
    void setDamping(float damping);
    void setWetLevel(float wet);
    void setDryLevel(float dry);

private:
    void updateParameters();
    
    juce::Reverb reverb;
    float roomSize;
    float damping;
    float wetLevel;
    float dryLevel;
    float width;
    bool freezeMode;
};

//==============================================================================
// Chorus Effect
//==============================================================================

class ChorusEffect
{
public:
    ChorusEffect();
    
    void prepare(double sampleRate, int samplesPerBlock);
    void processAudio(juce::AudioBuffer<float>& buffer);
    
    void setRate(float rate);
    void setDepth(float depth);
    void setCentreDelay(float delay);
    void setFeedback(float feedback);
    void setMix(float mix);

private:
    juce::AudioBuffer<float> delayBuffer;
    float rate;
    float depth;
    float centreDelay;
    float feedback;
    float mix;
    
    double sampleRate;
    float lfoPhase;
    int writePosition;
};

//==============================================================================
// Effects Processor
//==============================================================================

class EffectsProcessor
{
public:
    EffectsProcessor();
    
    void prepare(double sampleRate, int samplesPerBlock);
    void processAudio(juce::AudioBuffer<float>& buffer);
    
    void enableReverb(bool enable);
    void enableChorus(bool enable);
    
    ReverbEffect& getReverb();
    ChorusEffect& getChorus();

private:
    ReverbEffect reverbEffect;
    ChorusEffect chorusEffect;
    
    bool reverbEnabled;
    bool chorusEnabled;
};

