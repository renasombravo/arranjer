#pragma once

#include "StyleParser.h"
#include <JuceHeader.h>
#include <vector>
#include <string>

struct MidiEvent
{
    int tick;
    int note;
    int velocity;
    int duration;
};

using MidiMessage = juce::MidiMessage;

class AccompanimentGenerator
{
public:
    AccompanimentGenerator();
    ~AccompanimentGenerator();

    void setStyleData(const StyleData& style);
    void setChord(const std::string& chordName);
    void setSection(StyleSectionType section);
    
    void start();
    void stop();
    void setTempo(int tempo);
    
    std::vector<MidiMessage> getNextMidiEvents(int numSamples, double sampleRate);

private:
    void generateAccompaniment();
    std::vector<int> parseChord(const std::string& chord);
    void generateRhythmPattern(const std::vector<int>& chordNotes);
    void generateMainPattern(const std::vector<int>& chordNotes);
    void generateIntroPattern(const std::vector<int>& chordNotes);
    void generateFillPattern(const std::vector<int>& chordNotes);
    void generateChordEvents(std::vector<MidiMessage>& events, int sampleOffset);

    StyleData currentStyleData;
    StyleSectionType currentSection;
    std::string currentChord;
    std::vector<MidiEvent> accompanimentPattern;
    
    bool isPlaying;
    int currentTempo;
    int playbackPosition;
};

