#pragma once

#include <JuceHeader.h>
#include <functional>
#include <map>

/**
 * MidiIO - MIDI Input/Output management
 * Handles MIDI device detection, input/output routing, and message processing
 * Enhanced for Kontakt8 and 88-key controller support
 */

struct MidiControllerInfo
{
    juce::String name;
    juce::String identifier;
    int numKeys;
    bool hasModWheel;
    bool hasPitchBend;
    bool hasSustainPedal;
    bool isKontakt8Compatible;
};

class MidiIO : public juce::MidiInputCallback
{
public:
    MidiIO();
    ~MidiIO();

    // MIDI Input
    juce::StringArray getAvailableMidiInputs();
    bool setMidiInput(const juce::String& deviceIdentifier);
    void closeMidiInput();

    // MIDI Output
    juce::StringArray getAvailableMidiOutputs();
    bool setMidiOutput(const juce::String& deviceIdentifier);
    void closeMidiOutput();
    void sendMidiMessage(const juce::MidiMessage& message);

    // MIDI Clock
    void startMidiClock();
    void stopMidiClock();
    void sendMidiClock();
    void setMidiClockTempo(double bpm);

    // Device management
    void refreshMidiDevices();
    bool isMidiInputOpen() const;
    bool isMidiOutputOpen() const;
    
    // Controller detection
    std::vector<MidiControllerInfo> detectControllers();
    bool isKontakt8Controller(const juce::String& deviceName);
    bool is88KeyController(const juce::String& deviceName);
    
    // MIDI Learn
    void startMidiLearn(std::function<void(int, int)> callback);
    void stopMidiLearn();
    bool isMidiLearning() const;
    
    // Virtual MIDI ports for Kontakt8
    bool createVirtualMidiPort(const juce::String& portName);
    void closeVirtualMidiPort();
    bool hasVirtualMidiPort() const;
    
    // Callback registration
    void setNoteOnCallback(std::function<void(int, int, int)> callback);
    void setNoteOffCallback(std::function<void(int, int, int)> callback);
    void setControlChangeCallback(std::function<void(int, int, int)> callback);
    void setPitchBendCallback(std::function<void(int, int)> callback);
    
    // MidiInputCallback implementation
    void handleIncomingMidiMessage(juce::MidiInput* source, const juce::MidiMessage& message) override;

private:
    // MIDI devices
    std::unique_ptr<juce::MidiInput> midiInput;
    std::unique_ptr<juce::MidiOutput> midiOutput;
    std::unique_ptr<juce::MidiOutput> virtualMidiOutput;
    
    // MIDI clock
    bool midiClockEnabled = false;
    double midiClockTempo = 120.0;
    int midiClockCounter = 0;
    
    // Device lists
    juce::Array<juce::MidiDeviceInfo> availableInputs;
    juce::Array<juce::MidiDeviceInfo> availableOutputs;
    
    // MIDI Learn
    bool midiLearning = false;
    std::function<void(int, int)> midiLearnCallback;
    
    // Callbacks
    std::function<void(int, int, int)> noteOnCallback;
    std::function<void(int, int, int)> noteOffCallback;
    std::function<void(int, int, int)> controlChangeCallback;
    std::function<void(int, int)> pitchBendCallback;
    
    // Controller mapping
    std::map<juce::String, MidiControllerInfo> knownControllers;
    void initializeKnownControllers();
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MidiIO)
};

