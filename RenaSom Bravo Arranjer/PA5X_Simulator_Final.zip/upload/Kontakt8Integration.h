#pragma once

#include <JuceHeader.h>
#include "MidiIO.h"
#include <map>
#include <vector>

struct KontaktInstrument
{
    int channel;
    juce::String name;
    juce::String path;
    int bank;
    int program;
    bool isLoaded;
    
    KontaktInstrument()
        : channel(1), bank(0), program(0), isLoaded(false) {}
};

class Kontakt8Integration
{
public:
    Kontakt8Integration();
    ~Kontakt8Integration();

    // Inicialização e conexão
    bool initialize(MidiIO* midiIO);
    void disconnect();
    bool isConnected() const { return isConnected; }
    bool isKontakt8Available() const { return isKontaktLoaded; }
    
    // Gerenciamento de instrumentos
    bool loadInstrument(int channel, const juce::String& instrumentPath, const juce::String& instrumentName);
    void unloadInstrument(int channel);
    void setInstrumentParameter(int channel, int parameterId, float value);
    
    // Controle MIDI
    void sendProgramChange(int channel, int bank, int program);
    void sendControlChange(int channel, int controller, int value);
    void sendAllNotesOff(int channel);
    void sendPanic();
    
    // Informações
    std::vector<KontaktInstrument> getLoadedInstruments() const;
    KontaktInstrument* getInstrument(int channel);
    bool isInstrumentLoaded(int channel) const;
    
    // Controle global
    void setMasterVolume(float volume);
    
    // Configuração padrão
    const std::vector<KontaktInstrument>& getDefaultInstruments() const { return defaultInstruments; }

private:
    // Detecção e configuração
    void detectKontakt8();
    void loadDefaultConfiguration();
    
    // Utilitários MIDI
    std::vector<uint8_t> createLoadInstrumentSysEx(int channel, const juce::String& instrumentPath);
    void sendNRPN(int channel, int parameter, int value);
    
    // Membros
    MidiIO* midiIO;
    std::map<int, KontaktInstrument> kontaktInstruments;
    std::vector<KontaktInstrument> defaultInstruments;
    
    bool isConnected;
    bool isKontaktLoaded;
    int kontaktChannel;
};

