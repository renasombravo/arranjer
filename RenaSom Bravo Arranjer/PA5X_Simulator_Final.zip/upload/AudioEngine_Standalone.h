#pragma once

#include <vector>
#include <memory>
#include <cstdint>
#include <functional>
#include <thread>
#include <atomic>
#include <mutex>

// Standalone audio buffer implementation
struct StandaloneAudioBuffer
{
    std::vector<std::vector<float>> channels;
    int numChannels;
    int numSamples;
    
    StandaloneAudioBuffer(int channels, int samples) 
        : numChannels(channels), numSamples(samples)
    {
        this->channels.resize(channels);
        for (auto& channel : this->channels)
        {
            channel.resize(samples, 0.0f);
        }
    }
    
    void clear()
    {
        for (auto& channel : channels)
        {
            std::fill(channel.begin(), channel.end(), 0.0f);
        }
    }
    
    float* getWritePointer(int channel)
    {
        if (channel < numChannels)
            return channels[channel].data();
        return nullptr;
    }
    
    const float* getReadPointer(int channel) const
    {
        if (channel < numChannels)
            return channels[channel].data();
        return nullptr;
    }
    
    void addSample(int channel, int sample, float value)
    {
        if (channel < numChannels && sample < numSamples)
        {
            channels[channel][sample] += value;
        }
    }
};

struct StandaloneAudioSourceChannelInfo
{
    StandaloneAudioBuffer* buffer;
    int startSample;
    int numSamples;
    
    void clearActiveBufferRegion()
    {
        if (buffer)
            buffer->clear();
    }
};

/**
 * AudioEngineStandalone - Core audio processing engine without JUCE
 * Handles audio I/O, mixing, and real-time processing
 * Designed for 240 voice polyphony with low latency
 */
class AudioEngineStandalone
{
public:
    AudioEngineStandalone();
    ~AudioEngineStandalone();

    // Audio setup
    bool initialize();
    void prepareToPlay(int samplesPerBlockExpected, double sampleRate);
    void getNextAudioBlock(const StandaloneAudioSourceChannelInfo& bufferToFill);
    void releaseResources();
    
    // Audio processing
    void processAudioBlock(const StandaloneAudioSourceChannelInfo& bufferToFill);
    void addAudioSource(std::function<void(StandaloneAudioBuffer&)> source);
    void removeAllAudioSources();
    
    // Configuration
    void setMaxPolyphony(int voices);
    void setBufferSize(int samples);
    void setSampleRate(double rate);
    
    // Audio device management
    bool initializeAudioDevice();
    std::vector<std::string> getAvailableAudioDevices();
    bool setAudioDevice(const std::string& deviceName);
    
    // Getters
    double getSampleRate() const { return sampleRate; }
    int getBufferSize() const { return bufferSize; }
    int getMaxPolyphony() const { return maxPolyphony; }
    bool isInitialized() const { return initialized; }
    double getCurrentCpuUsage() const { return cpuUsage; }

private:
    // Audio parameters
    std::atomic<double> sampleRate;
    std::atomic<int> bufferSize;
    std::atomic<int> maxPolyphony;
    std::atomic<bool> initialized;
    std::atomic<double> cpuUsage;
    
    // Audio sources
    std::vector<std::function<void(StandaloneAudioBuffer&)>> audioSources;
    std::mutex audioSourcesMutex;
    
    // Internal buffers
    std::unique_ptr<StandaloneAudioBuffer> mixBuffer;
    
    // Audio thread
    std::thread audioThread;
    std::atomic<bool> shouldStop;
    
    // Processing
    void audioThreadFunction();
    void mixAudioSources(StandaloneAudioBuffer& outputBuffer);
    void applyMasterEffects(StandaloneAudioBuffer& buffer);
    
    // Platform-specific audio
#ifdef __linux__
    void* alsaHandle;
    bool initializeALSA();
    void closeALSA();
#endif
};

