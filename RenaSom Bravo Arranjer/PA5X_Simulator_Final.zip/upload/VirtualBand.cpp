#include "VirtualBand.h"

VirtualBand::VirtualBand()
    : isPlaying(false)
    , currentTempo(120)
    , masterVolume(1.0f)
{
    // Inicializa instrumentos padrão
    initializeDefaultInstruments();
}

VirtualBand::~VirtualBand()
{
    stop();
}

void VirtualBand::initialize(MidiIO* midiIO, SoundFontLoader* soundFontLoader)
{
    this->midiIO = midiIO;
    this->soundFontLoader = soundFontLoader;
    
    // Configura callbacks MIDI
    if (midiIO)
    {
        midiIO->setNoteOnCallback([this](int channel, int note, int velocity) {
            handleNoteOn(channel, note, velocity);
        });
        
        midiIO->setNoteOffCallback([this](int channel, int note, int velocity) {
            handleNoteOff(channel, note, velocity);
        });
        
        midiIO->setControlChangeCallback([this](int channel, int controller, int value) {
            handleControlChange(channel, controller, value);
        });
    }
    
    // Cria porta virtual para Kontakt8
    if (midiIO && !midiIO->hasVirtualMidiPort())
    {
        midiIO->createVirtualMidiPort("ArrangerSimulator_Kontakt8");
    }
}

void VirtualBand::addInstrument(const VirtualInstrument& instrument)
{
    instruments[instrument.channel] = instrument;
    DBG("Added instrument: " << instrument.name << " on channel " << instrument.channel);
}

void VirtualBand::removeInstrument(int channel)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        instruments.erase(it);
        DBG("Removed instrument from channel " << channel);
    }
}

void VirtualBand::setInstrumentProgram(int channel, int bank, int program)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        it->second.bank = bank;
        it->second.program = program;
        
        // Envia Program Change para Kontakt8
        if (midiIO)
        {
            juce::MidiMessage bankSelect = juce::MidiMessage::controllerEvent(channel, 0, bank >> 7);
            juce::MidiMessage bankSelectLSB = juce::MidiMessage::controllerEvent(channel, 32, bank & 0x7F);
            juce::MidiMessage programChange = juce::MidiMessage::programChange(channel, program);
            
            midiIO->sendMidiMessage(bankSelect);
            midiIO->sendMidiMessage(bankSelectLSB);
            midiIO->sendMidiMessage(programChange);
        }
        
        DBG("Set instrument program - Ch:" << channel << " Bank:" << bank << " Program:" << program);
    }
}

void VirtualBand::setInstrumentVolume(int channel, float volume)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        it->second.volume = std::clamp(volume, 0.0f, 1.0f);
        
        // Envia Volume CC para Kontakt8
        if (midiIO)
        {
            int ccValue = static_cast<int>(volume * 127);
            juce::MidiMessage volumeCC = juce::MidiMessage::controllerEvent(channel, 7, ccValue);
            midiIO->sendMidiMessage(volumeCC);
        }
        
        DBG("Set instrument volume - Ch:" << channel << " Vol:" << volume);
    }
}

void VirtualBand::setInstrumentPan(int channel, float pan)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        it->second.pan = std::clamp(pan, -1.0f, 1.0f);
        
        // Envia Pan CC para Kontakt8
        if (midiIO)
        {
            int ccValue = static_cast<int>((pan + 1.0f) * 63.5f);
            juce::MidiMessage panCC = juce::MidiMessage::controllerEvent(channel, 10, ccValue);
            midiIO->sendMidiMessage(panCC);
        }
        
        DBG("Set instrument pan - Ch:" << channel << " Pan:" << pan);
    }
}

void VirtualBand::muteInstrument(int channel, bool mute)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        it->second.muted = mute;
        
        if (mute)
        {
            // Para todas as notas do canal
            stopAllNotesOnChannel(channel);
        }
        
        DBG("Instrument mute - Ch:" << channel << " Muted:" << mute);
    }
}

void VirtualBand::soloInstrument(int channel, bool solo)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        it->second.solo = solo;
        DBG("Instrument solo - Ch:" << channel << " Solo:" << solo);
    }
}

void VirtualBand::playNote(int channel, int note, int velocity)
{
    auto it = instruments.find(channel);
    if (it != instruments.end() && !it->second.muted)
    {
        // Verifica se há instrumentos em solo
        bool hasSolo = false;
        for (const auto& inst : instruments)
        {
            if (inst.second.solo)
            {
                hasSolo = true;
                break;
            }
        }
        
        // Só toca se não estiver mutado e (não há solo ou este instrumento está em solo)
        if (!hasSolo || it->second.solo)
        {
            // Envia para Kontakt8
            if (midiIO)
            {
                juce::MidiMessage noteOn = juce::MidiMessage::noteOn(channel, note, static_cast<uint8_t>(velocity));
                midiIO->sendMidiMessage(noteOn);
            }
            
            // Adiciona à lista de notas ativas
            ActiveNote activeNote;
            activeNote.channel = channel;
            activeNote.note = note;
            activeNote.velocity = velocity;
            activeNote.startTime = juce::Time::getMillisecondCounterHiRes();
            
            activeNotes.push_back(activeNote);
            
            DBG("Play note - Ch:" << channel << " Note:" << note << " Vel:" << velocity);
        }
    }
}

void VirtualBand::stopNote(int channel, int note)
{
    // Remove da lista de notas ativas
    activeNotes.erase(
        std::remove_if(activeNotes.begin(), activeNotes.end(),
            [channel, note](const ActiveNote& n) {
                return n.channel == channel && n.note == note;
            }),
        activeNotes.end()
    );
    
    // Envia para Kontakt8
    if (midiIO)
    {
        juce::MidiMessage noteOff = juce::MidiMessage::noteOff(channel, note);
        midiIO->sendMidiMessage(noteOff);
    }
    
    DBG("Stop note - Ch:" << channel << " Note:" << note);
}

void VirtualBand::stopAllNotes()
{
    for (const auto& note : activeNotes)
    {
        if (midiIO)
        {
            juce::MidiMessage noteOff = juce::MidiMessage::noteOff(note.channel, note.note);
            midiIO->sendMidiMessage(noteOff);
        }
    }
    
    activeNotes.clear();
    DBG("Stopped all notes");
}

void VirtualBand::stopAllNotesOnChannel(int channel)
{
    // Remove notas ativas do canal
    auto it = std::remove_if(activeNotes.begin(), activeNotes.end(),
        [channel](const ActiveNote& n) {
            return n.channel == channel;
        });
    
    // Envia note off para as notas removidas
    for (auto noteIt = it; noteIt != activeNotes.end(); ++noteIt)
    {
        if (midiIO)
        {
            juce::MidiMessage noteOff = juce::MidiMessage::noteOff(noteIt->channel, noteIt->note);
            midiIO->sendMidiMessage(noteOff);
        }
    }
    
    activeNotes.erase(it, activeNotes.end());
    DBG("Stopped all notes on channel " << channel);
}

void VirtualBand::start()
{
    isPlaying = true;
    
    // Inicia clock MIDI
    if (midiIO)
    {
        midiIO->setMidiClockTempo(currentTempo);
        midiIO->startMidiClock();
    }
    
    DBG("Virtual band started");
}

void VirtualBand::stop()
{
    isPlaying = false;
    
    // Para todas as notas
    stopAllNotes();
    
    // Para clock MIDI
    if (midiIO)
    {
        midiIO->stopMidiClock();
    }
    
    DBG("Virtual band stopped");
}

void VirtualBand::setTempo(int tempo)
{
    currentTempo = std::clamp(tempo, 60, 200);
    
    if (midiIO)
    {
        midiIO->setMidiClockTempo(currentTempo);
    }
    
    DBG("Tempo set to " << currentTempo << " BPM");
}

void VirtualBand::setMasterVolume(float volume)
{
    masterVolume = std::clamp(volume, 0.0f, 1.0f);
    DBG("Master volume set to " << masterVolume);
}

std::vector<VirtualInstrument> VirtualBand::getInstruments() const
{
    std::vector<VirtualInstrument> result;
    for (const auto& pair : instruments)
    {
        result.push_back(pair.second);
    }
    return result;
}

VirtualInstrument* VirtualBand::getInstrument(int channel)
{
    auto it = instruments.find(channel);
    return (it != instruments.end()) ? &it->second : nullptr;
}

bool VirtualBand::isInstrumentActive(int channel) const
{
    auto it = instruments.find(channel);
    return it != instruments.end();
}

void VirtualBand::handleNoteOn(int channel, int note, int velocity)
{
    playNote(channel, note, velocity);
}

void VirtualBand::handleNoteOff(int channel, int note, int velocity)
{
    stopNote(channel, note);
}

void VirtualBand::handleControlChange(int channel, int controller, int value)
{
    auto it = instruments.find(channel);
    if (it != instruments.end())
    {
        switch (controller)
        {
            case 7: // Volume
                setInstrumentVolume(channel, value / 127.0f);
                break;
                
            case 10: // Pan
                setInstrumentPan(channel, (value - 64) / 64.0f);
                break;
                
            case 64: // Sustain pedal
                // Encaminha para Kontakt8
                if (midiIO)
                {
                    juce::MidiMessage sustainCC = juce::MidiMessage::controllerEvent(channel, controller, value);
                    midiIO->sendMidiMessage(sustainCC);
                }
                break;
                
            case 1: // Modulation wheel
                // Encaminha para Kontakt8
                if (midiIO)
                {
                    juce::MidiMessage modCC = juce::MidiMessage::controllerEvent(channel, controller, value);
                    midiIO->sendMidiMessage(modCC);
                }
                break;
                
            default:
                // Encaminha outros CCs para Kontakt8
                if (midiIO)
                {
                    juce::MidiMessage cc = juce::MidiMessage::controllerEvent(channel, controller, value);
                    midiIO->sendMidiMessage(cc);
                }
                break;
        }
    }
}

void VirtualBand::initializeDefaultInstruments()
{
    // Piano
    VirtualInstrument piano;
    piano.channel = 1;
    piano.name = "Acoustic Grand Piano";
    piano.bank = 0;
    piano.program = 0;
    piano.volume = 0.8f;
    piano.pan = 0.0f;
    piano.muted = false;
    piano.solo = false;
    piano.isKontakt8Instrument = true;
    addInstrument(piano);
    
    // Bass
    VirtualInstrument bass;
    bass.channel = 2;
    bass.name = "Acoustic Bass";
    bass.bank = 0;
    bass.program = 32;
    bass.volume = 0.7f;
    bass.pan = -0.2f;
    bass.muted = false;
    bass.solo = false;
    bass.isKontakt8Instrument = true;
    addInstrument(bass);
    
    // Drums
    VirtualInstrument drums;
    drums.channel = 10; // Canal padrão de bateria
    drums.name = "Standard Drum Kit";
    drums.bank = 128;
    drums.program = 0;
    drums.volume = 0.9f;
    drums.pan = 0.0f;
    drums.muted = false;
    drums.solo = false;
    drums.isKontakt8Instrument = true;
    addInstrument(drums);
    
    // Guitar
    VirtualInstrument guitar;
    guitar.channel = 3;
    guitar.name = "Acoustic Guitar (nylon)";
    guitar.bank = 0;
    guitar.program = 24;
    guitar.volume = 0.6f;
    guitar.pan = 0.3f;
    guitar.muted = false;
    guitar.solo = false;
    guitar.isKontakt8Instrument = true;
    addInstrument(guitar);
    
    DBG("Default instruments initialized");
}

