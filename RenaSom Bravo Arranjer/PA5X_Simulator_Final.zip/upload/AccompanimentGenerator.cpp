#include "AccompanimentGenerator.h"
#include <algorithm>
#include <random>

AccompanimentGenerator::AccompanimentGenerator()
    : currentSection(StyleSectionType::MAIN_A)
    , isPlaying(false)
    , currentTempo(120)
{
}

AccompanimentGenerator::~AccompanimentGenerator()
{
}

void AccompanimentGenerator::setStyleData(const StyleData& style)
{
    currentStyleData = style;
    currentTempo = style.tempo;
}

void AccompanimentGenerator::setChord(const std::string& chordName)
{
    currentChord = chordName;
    generateAccompaniment();
}

void AccompanimentGenerator::setSection(StyleSectionType section)
{
    currentSection = section;
    generateAccompaniment();
}

void AccompanimentGenerator::start()
{
    isPlaying = true;
    playbackPosition = 0;
}

void AccompanimentGenerator::stop()
{
    isPlaying = false;
    playbackPosition = 0;
}

void AccompanimentGenerator::setTempo(int tempo)
{
    currentTempo = tempo;
}

std::vector<MidiMessage> AccompanimentGenerator::getNextMidiEvents(int numSamples, double sampleRate)
{
    std::vector<MidiMessage> events;
    
    if (!isPlaying || currentStyleData.sections.empty())
        return events;

    // Calcula quantos samples por beat
    double samplesPerBeat = (60.0 / currentTempo) * sampleRate;
    double samplesPerTick = samplesPerBeat / 480.0; // 480 ticks por beat (resolução MIDI padrão)

    // Processa eventos MIDI da seção atual
    auto sectionData = currentStyleData.sections.find(currentSection);
    if (sectionData != currentStyleData.sections.end())
    {
        // Simula processamento de dados MIDI
        for (int i = 0; i < numSamples; i++)
        {
            if ((playbackPosition + i) % static_cast<int>(samplesPerBeat) == 0)
            {
                // Gera eventos de acompanhamento baseados no acorde atual
                generateChordEvents(events, i);
            }
        }
    }

    playbackPosition += numSamples;
    return events;
}

void AccompanimentGenerator::generateAccompaniment()
{
    // Gera padrão de acompanhamento baseado no acorde e seção atual
    accompanimentPattern.clear();
    
    if (currentChord.empty())
        return;

    // Analisa o acorde e gera notas
    std::vector<int> chordNotes = parseChord(currentChord);
    
    // Gera padrão rítmico baseado na seção
    generateRhythmPattern(chordNotes);
}

std::vector<int> AccompanimentGenerator::parseChord(const std::string& chord)
{
    std::vector<int> notes;
    
    // Parsing básico de acordes (C, Dm, G7, etc.)
    if (chord == "C")
    {
        notes = {60, 64, 67}; // C E G
    }
    else if (chord == "Dm")
    {
        notes = {62, 65, 69}; // D F A
    }
    else if (chord == "Em")
    {
        notes = {64, 67, 71}; // E G B
    }
    else if (chord == "F")
    {
        notes = {65, 69, 72}; // F A C
    }
    else if (chord == "G")
    {
        notes = {67, 71, 74}; // G B D
    }
    else if (chord == "Am")
    {
        notes = {69, 72, 76}; // A C E
    }
    else if (chord == "G7")
    {
        notes = {67, 71, 74, 77}; // G B D F
    }
    else
    {
        // Acorde padrão C maior
        notes = {60, 64, 67};
    }
    
    return notes;
}

void AccompanimentGenerator::generateRhythmPattern(const std::vector<int>& chordNotes)
{
    // Gera padrão rítmico baseado no tipo de seção
    switch (currentSection)
    {
        case StyleSectionType::MAIN_A:
        case StyleSectionType::MAIN_B:
            generateMainPattern(chordNotes);
            break;
            
        case StyleSectionType::INTRO_A:
        case StyleSectionType::INTRO_B:
            generateIntroPattern(chordNotes);
            break;
            
        case StyleSectionType::FILL_IN_AA:
        case StyleSectionType::FILL_IN_BB:
            generateFillPattern(chordNotes);
            break;
            
        default:
            generateMainPattern(chordNotes);
            break;
    }
}

void AccompanimentGenerator::generateMainPattern(const std::vector<int>& chordNotes)
{
    // Padrão principal: baixo no tempo 1 e 3, acordes no tempo 2 e 4
    for (int beat = 0; beat < 4; beat++)
    {
        int tick = beat * 480; // 480 ticks por beat
        
        if (beat % 2 == 0) // Tempos 1 e 3
        {
            // Baixo
            if (!chordNotes.empty())
            {
                MidiEvent event;
                event.tick = tick;
                event.note = chordNotes[0] - 12; // Oitava abaixo
                event.velocity = 80;
                event.duration = 240; // Meio beat
                accompanimentPattern.push_back(event);
            }
        }
        else // Tempos 2 e 4
        {
            // Acorde
            for (size_t i = 1; i < chordNotes.size(); i++)
            {
                MidiEvent event;
                event.tick = tick;
                event.note = chordNotes[i];
                event.velocity = 60;
                event.duration = 240;
                accompanimentPattern.push_back(event);
            }
        }
    }
}

void AccompanimentGenerator::generateIntroPattern(const std::vector<int>& chordNotes)
{
    // Padrão de introdução mais simples
    for (int beat = 0; beat < 4; beat++)
    {
        int tick = beat * 480;
        
        // Toca o acorde completo em cada tempo
        for (size_t i = 0; i < chordNotes.size(); i++)
        {
            MidiEvent event;
            event.tick = tick;
            event.note = chordNotes[i];
            event.velocity = 70;
            event.duration = 480; // Beat completo
            accompanimentPattern.push_back(event);
        }
    }
}

void AccompanimentGenerator::generateFillPattern(const std::vector<int>& chordNotes)
{
    // Padrão de fill com mais variação
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, chordNotes.size() - 1);
    
    for (int sixteenth = 0; sixteenth < 16; sixteenth++)
    {
        int tick = sixteenth * 120; // 16th notes
        
        if (sixteenth % 4 == 0) // Acentos principais
        {
            int noteIndex = dis(gen);
            MidiEvent event;
            event.tick = tick;
            event.note = chordNotes[noteIndex];
            event.velocity = 90;
            event.duration = 120;
            accompanimentPattern.push_back(event);
        }
    }
}

void AccompanimentGenerator::generateChordEvents(std::vector<MidiMessage>& events, int sampleOffset)
{
    // Converte eventos do padrão para mensagens MIDI
    for (const auto& event : accompanimentPattern)
    {
        // Note On
        MidiMessage noteOn = MidiMessage::noteOn(1, event.note, static_cast<uint8_t>(event.velocity));
        events.push_back(noteOn);
        
        // Note Off (agendado para depois)
        // Isso seria implementado com um scheduler mais sofisticado
    }
}

