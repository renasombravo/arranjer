#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <cstring>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct SF2Header
{
    uint32_t riffSignature;  // "RIFF"
    uint32_t fileSize;
    uint32_t sf2Signature;   // "sfbk"
};

struct SF2Zone
{
    int keyRangeLow;
    int keyRangeHigh;
    int velRangeLow;
    int velRangeHigh;
    int sampleIndex;
    int rootKey;
    int fineTune;
    int scaleTuning;
};

struct SF2Preset
{
    int bank;
    int program;
    char name[256];
    std::vector<SF2Zone> zones;
};

struct SampleData
{
    std::string name;
    std::vector<float> audioData;
    int sampleRate;
    int rootKey;
    int fineTune;
    int scaleTuning;
    int loopStart;
    int loopEnd;
    bool isLooped;
    
    SampleData() : sampleRate(44100), rootKey(60), fineTune(0), scaleTuning(100),
                   loopStart(0), loopEnd(0), isLooped(false) {}
};

struct SoundFontData
{
    std::string filename;
    uint32_t fileSize;
    std::vector<SF2Preset> presets;
    std::vector<SampleData> samples;
};

struct PresetInfo
{
    int bank;
    int program;
    std::string name;
};

class SoundFontLoader
{
public:
    SoundFontLoader();
    ~SoundFontLoader();

    bool loadSoundFont(const std::string& filename);
    void unloadSoundFont();
    bool isLoaded() const;
    
    const SoundFontData& getSoundFontData() const;
    std::vector<PresetInfo> getPresetList() const;
    SampleData getSample(int presetBank, int presetProgram, int note, int velocity);

private:
    void loadPresets(std::ifstream& file);
    void loadSamples(std::ifstream& file);

    SoundFontData currentSoundFont;
    bool isLoaded;
};

