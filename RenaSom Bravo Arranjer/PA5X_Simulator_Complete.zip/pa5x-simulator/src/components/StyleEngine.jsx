import { useState, useEffect } from 'react'

// Estilos expandidos com ritmos brasileiros e internacionais
export const STYLE_CATEGORIES = {
  'POP': {
    color: 'bg-blue-600',
    styles: ['8Beat Pop', '16Beat', 'Pop Rock', 'Synth Pop', 'Dance Pop']
  },
  'ROCK': {
    color: 'bg-red-600',
    styles: ['Rock', 'Hard Rock', 'Soft Rock', 'Blues Rock', 'Country Rock']
  },
  'JAZZ': {
    color: 'bg-orange-600',
    styles: ['Jazz Swing', 'Jazz Ballad', 'Bebop', 'Smooth Jazz', 'Latin Jazz']
  },
  'LATIN': {
    color: 'bg-green-600',
    styles: ['Bossa Nova', 'Samba', 'Salsa', 'Merengue', 'Bachata', 'Tango']
  },
  'BRAZILIAN': {
    color: 'bg-yellow-600',
    styles: ['Samba', 'Bossa Nova', 'Forró', 'Baião', 'Xote', 'Frevo', 'Maracatu', 'Axé']
  },
  'WORLD': {
    color: 'bg-purple-600',
    styles: ['Reggae', 'Afrobeat', 'Celtic', 'Flamenco', 'Klezmer', 'Arabic']
  },
  'DANCE': {
    color: 'bg-pink-600',
    styles: ['House', 'Techno', 'Trance', 'Disco', 'Funk', 'Hip Hop']
  },
  'BALLAD': {
    color: 'bg-slate-600',
    styles: ['Ballad', 'Slow Rock', 'R&B Ballad', 'Gospel Ballad', 'Power Ballad']
  },
  'COUNTRY': {
    color: 'bg-amber-600',
    styles: ['Country', 'Bluegrass', 'Country Rock', 'Western Swing', 'Honky Tonk']
  }
}

// Padrões de ritmo expandidos
export const RHYTHM_PATTERNS = {
  // Pop Styles
  '8Beat Pop': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    bass: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    tempo: [100, 140]
  },
  
  '16Beat': {
    kick: [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    bass: [1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1],
    tempo: [110, 150]
  },

  // Rock Styles
  'Rock': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    bass: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    tempo: [120, 160]
  },

  'Hard Rock': {
    kick: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    bass: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    tempo: [140, 180]
  },

  // Jazz Styles
  'Jazz Swing': {
    kick: [1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1],
    snare: [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    hihat: [1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1],
    bass: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    tempo: [120, 200]
  },

  // Brazilian Styles
  'Samba': {
    kick: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    snare: [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    bass: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    percussion: [1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1], // Tamborim
    tempo: [100, 140]
  },

  'Bossa Nova': {
    kick: [1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1],
    snare: [0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0],
    hihat: [1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1],
    bass: [1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0],
    tempo: [120, 160]
  },

  'Forró': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    bass: [1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1],
    triangle: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    tempo: [120, 150]
  },

  'Baião': {
    kick: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    snare: [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0],
    hihat: [1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1],
    bass: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    zabumba: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    tempo: [100, 130]
  },

  'Axé': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1],
    hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    bass: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    surdo: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    tempo: [130, 160]
  },

  // Ballad Styles
  'Ballad': {
    kick: [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    bass: [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0],
    tempo: [60, 90]
  },

  // Country Styles
  'Country': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    hihat: [1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    bass: [1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1],
    tempo: [120, 140]
  }
}

// Progressões de acordes por estilo
export const CHORD_PROGRESSIONS = {
  '8Beat Pop': ['C', 'Am', 'F', 'G'],
  '16Beat': ['C', 'G', 'Am', 'F'],
  'Rock': ['C', 'F', 'G', 'C'],
  'Hard Rock': ['Em', 'C', 'G', 'D'],
  'Jazz Swing': ['Cmaj7', 'Am7', 'Dm7', 'G7'],
  'Ballad': ['C', 'Em', 'Am', 'F', 'C', 'G', 'Am', 'F'],
  'Bossa Nova': ['Cmaj7', 'Dm7', 'G7', 'Cmaj7'],
  'Samba': ['C', 'G7', 'C', 'G7'],
  'Forró': ['C', 'F', 'G', 'C'],
  'Baião': ['C', 'F', 'C', 'G', 'C'],
  'Axé': ['C', 'F', 'G', 'Am'],
  'Country': ['C', 'F', 'C', 'G', 'C']
}

// Variações de estilo
export const STYLE_VARIATIONS = {
  'INTRO': {
    name: 'INTRO',
    color: 'bg-green-600',
    measures: 4,
    description: 'Introdução do estilo'
  },
  'MAIN_A': {
    name: 'MAIN A',
    color: 'bg-blue-500',
    measures: 0, // Loop infinito
    description: 'Variação principal A'
  },
  'MAIN_B': {
    name: 'MAIN B',
    color: 'bg-blue-600',
    measures: 0,
    description: 'Variação principal B'
  },
  'MAIN_C': {
    name: 'MAIN C',
    color: 'bg-blue-700',
    measures: 0,
    description: 'Variação principal C'
  },
  'MAIN_D': {
    name: 'MAIN D',
    color: 'bg-blue-800',
    measures: 0,
    description: 'Variação principal D'
  },
  'FILL_IN': {
    name: 'FILL IN',
    color: 'bg-orange-600',
    measures: 1,
    description: 'Virada de bateria'
  },
  'BREAK': {
    name: 'BREAK',
    color: 'bg-purple-600',
    measures: 4,
    description: 'Pausa no acompanhamento'
  },
  'ENDING': {
    name: 'ENDING',
    color: 'bg-red-600',
    measures: 4,
    description: 'Final do estilo'
  }
}

export class StyleEngine {
  constructor(audioEngine) {
    this.audioEngine = audioEngine
    this.currentCategory = 'POP'
    this.currentStyle = '8Beat Pop'
    this.currentVariation = 'MAIN_A'
    this.tempo = 120
    this.isPlaying = false
    this.currentStep = 0
    this.currentMeasure = 0
    this.chordIndex = 0
    this.intervalId = null
    this.variationMeasures = 0
    
    // Callbacks
    this.onStepChange = null
    this.onMeasureChange = null
    this.onChordChange = null
    this.onVariationChange = null
    
    // Configurações
    this.swingFactor = 0 // 0 = straight, 1 = full swing
    this.humanization = 0.1 // Variação de timing
    this.accentPattern = [1, 0.8, 0.9, 0.8] // Acentos por beat
  }

  setCategory(category) {
    if (STYLE_CATEGORIES[category]) {
      this.currentCategory = category
      // Seleciona o primeiro estilo da categoria
      this.setStyle(STYLE_CATEGORIES[category].styles[0])
    }
  }

  setStyle(style) {
    if (RHYTHM_PATTERNS[style]) {
      this.currentStyle = style
      this.currentStep = 0
      this.chordIndex = 0
      this.currentMeasure = 0
      this.variationMeasures = 0
      
      // Ajusta tempo para o range do estilo
      const tempoRange = RHYTHM_PATTERNS[style].tempo
      if (tempoRange && (this.tempo < tempoRange[0] || this.tempo > tempoRange[1])) {
        this.setTempo(tempoRange[0])
      }
    }
  }

  setVariation(variation) {
    if (STYLE_VARIATIONS[variation]) {
      this.currentVariation = variation
      this.variationMeasures = 0
      
      if (this.onVariationChange) {
        this.onVariationChange(variation)
      }
    }
  }

  setTempo(bpm) {
    this.tempo = Math.max(60, Math.min(200, bpm))
    
    if (this.isPlaying) {
      this.stop()
      this.start()
    }
  }

  start() {
    if (this.isPlaying) return
    
    this.isPlaying = true
    this.currentStep = 0
    
    // Calcula o intervalo baseado no tempo (16ª notas)
    const stepInterval = (60 / this.tempo / 4) * 1000
    
    this.intervalId = setInterval(() => {
      this.playStep()
      this.currentStep = (this.currentStep + 1) % 16
      
      // A cada compasso (16 steps)
      if (this.currentStep === 0) {
        this.currentMeasure++
        this.variationMeasures++
        this.advanceChord()
        
        // Verifica se precisa mudar de variação
        this.checkVariationChange()
        
        if (this.onMeasureChange) {
          this.onMeasureChange(this.currentMeasure)
        }
      }
      
      if (this.onStepChange) {
        this.onStepChange(this.currentStep)
      }
    }, stepInterval)
  }

  stop() {
    this.isPlaying = false
    
    if (this.intervalId) {
      clearInterval(this.intervalId)
      this.intervalId = null
    }
    
    if (this.audioEngine) {
      this.audioEngine.stopAllNotes()
    }
  }

  playStep() {
    const pattern = RHYTHM_PATTERNS[this.currentStyle]
    if (!pattern || !this.audioEngine) return

    const step = this.currentStep
    const beatIndex = Math.floor(step / 4)
    const accent = this.accentPattern[beatIndex] || 1

    // Aplica humanização
    const humanizationDelay = (Math.random() - 0.5) * this.humanization * 10

    setTimeout(() => {
      // Toca elementos de percussão
      this.playPercussionElement('kick', pattern.kick, step, accent * 100)
      this.playPercussionElement('snare', pattern.snare, step, accent * 90)
      this.playPercussionElement('hihat', pattern.hihat, step, accent * 70)
      
      // Elementos específicos do estilo
      if (pattern.percussion) {
        this.playPercussionElement('percussion', pattern.percussion, step, accent * 60)
      }
      if (pattern.triangle) {
        this.playPercussionElement('triangle', pattern.triangle, step, accent * 50)
      }
      if (pattern.zabumba) {
        this.playPercussionElement('zabumba', pattern.zabumba, step, accent * 80)
      }
      if (pattern.surdo) {
        this.playPercussionElement('surdo', pattern.surdo, step, accent * 90)
      }

      // Toca baixo
      if (pattern.bass && pattern.bass[step]) {
        this.playBass(accent * 80)
      }
      
      // Toca acordes em alguns steps
      if (step % 4 === 0) {
        this.playChord(accent * 60)
      }
    }, humanizationDelay)
  }

  playPercussionElement(instrument, pattern, step, velocity) {
    if (pattern[step]) {
      let midiNote
      switch (instrument) {
        case 'kick': midiNote = 36; break // C2
        case 'snare': midiNote = 38; break // D2
        case 'hihat': midiNote = 42; break // F#2
        case 'percussion': midiNote = 76; break // E5 (Tamborim)
        case 'triangle': midiNote = 81; break // A5
        case 'zabumba': midiNote = 60; break // C4
        case 'surdo': midiNote = 35; break // B1
        default: midiNote = 36
      }
      
      this.audioEngine.playNote(midiNote, velocity, instrument)
    }
  }

  playBass(velocity) {
    const currentChord = this.getCurrentChord()
    const bassNote = this.getChordRoot(currentChord)
    this.audioEngine.playNote(bassNote, velocity, 'bass')
  }

  playChord(velocity) {
    const currentChord = this.getCurrentChord()
    const chordNotes = this.getChordNotes(currentChord)
    
    chordNotes.forEach((note, index) => {
      setTimeout(() => {
        this.audioEngine.playNote(note, velocity, 'piano')
      }, index * 10) // Pequeno delay para arpejo
    })
  }

  getCurrentChord() {
    const progression = CHORD_PROGRESSIONS[this.currentStyle] || ['C', 'F', 'G', 'C']
    return progression[this.chordIndex % progression.length]
  }

  advanceChord() {
    const progression = CHORD_PROGRESSIONS[this.currentStyle] || ['C', 'F', 'G', 'C']
    this.chordIndex = (this.chordIndex + 1) % progression.length
    
    if (this.onChordChange) {
      this.onChordChange(this.getCurrentChord())
    }
  }

  checkVariationChange() {
    const variation = STYLE_VARIATIONS[this.currentVariation]
    if (!variation || variation.measures === 0) return
    
    if (this.variationMeasures >= variation.measures) {
      // Volta para MAIN_A após variações temporárias
      if (['INTRO', 'FILL_IN', 'BREAK', 'ENDING'].includes(this.currentVariation)) {
        if (this.currentVariation === 'ENDING') {
          this.stop()
        } else {
          this.setVariation('MAIN_A')
        }
      }
    }
  }

  getChordRoot(chordName) {
    const noteMap = {
      'C': 48, 'C#': 49, 'Db': 49, 'D': 50, 'D#': 51, 'Eb': 51,
      'E': 52, 'F': 53, 'F#': 54, 'Gb': 54, 'G': 55, 'G#': 56,
      'Ab': 56, 'A': 57, 'A#': 58, 'Bb': 58, 'B': 59
    }
    
    const rootNote = chordName.replace(/[^A-G#b]/g, '')
    return noteMap[rootNote] || 48
  }

  getChordNotes(chordName) {
    const root = this.getChordRoot(chordName)
    
    if (chordName.includes('maj7')) {
      return [root + 12, root + 16, root + 19, root + 23]
    } else if (chordName.includes('m7')) {
      return [root + 12, root + 15, root + 19, root + 22]
    } else if (chordName.includes('7')) {
      return [root + 12, root + 16, root + 19, root + 22]
    } else if (chordName.includes('m')) {
      return [root + 12, root + 15, root + 19]
    } else {
      return [root + 12, root + 16, root + 19]
    }
  }

  // Métodos de controle de variação
  playIntro() {
    this.setVariation('INTRO')
  }

  playFillIn() {
    this.setVariation('FILL_IN')
  }

  playBreak() {
    this.setVariation('BREAK')
  }

  playEnding() {
    this.setVariation('ENDING')
  }

  // Getters
  getCurrentCategory() {
    return this.currentCategory
  }

  getCurrentStyle() {
    return this.currentStyle
  }

  getCurrentVariation() {
    return this.currentVariation
  }

  getTempo() {
    return this.tempo
  }

  getCurrentStep() {
    return this.currentStep
  }

  getCurrentMeasure() {
    return this.currentMeasure
  }

  isActive() {
    return this.isPlaying
  }

  getAvailableStyles(category) {
    return STYLE_CATEGORIES[category]?.styles || []
  }

  getStyleInfo(style) {
    const pattern = RHYTHM_PATTERNS[style]
    if (!pattern) return null
    
    return {
      name: style,
      tempoRange: pattern.tempo,
      hasPercussion: !!pattern.percussion,
      hasTriangle: !!pattern.triangle,
      hasZabumba: !!pattern.zabumba,
      hasSurdo: !!pattern.surdo
    }
  }
}

// Hook React para usar o StyleEngine
export function useStyleEngine(audioEngine) {
  const [styleEngine] = useState(() => new StyleEngine(audioEngine))
  const [currentCategory, setCurrentCategory] = useState('POP')
  const [currentStyle, setCurrentStyle] = useState('8Beat Pop')
  const [currentVariation, setCurrentVariation] = useState('MAIN_A')
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [currentMeasure, setCurrentMeasure] = useState(0)
  const [currentChord, setCurrentChord] = useState('C')

  useEffect(() => {
    // Configura callbacks
    styleEngine.onStepChange = setCurrentStep
    styleEngine.onMeasureChange = setCurrentMeasure
    styleEngine.onChordChange = setCurrentChord
    styleEngine.onVariationChange = setCurrentVariation

    return () => {
      styleEngine.stop()
    }
  }, [styleEngine])

  const startStop = () => {
    if (isPlaying) {
      styleEngine.stop()
      setIsPlaying(false)
    } else {
      styleEngine.start()
      setIsPlaying(true)
    }
  }

  const selectCategory = (category) => {
    styleEngine.setCategory(category)
    setCurrentCategory(category)
    setCurrentStyle(styleEngine.getCurrentStyle())
  }

  const selectStyle = (style) => {
    styleEngine.setStyle(style)
    setCurrentStyle(style)
  }

  const selectVariation = (variation) => {
    styleEngine.setVariation(variation)
  }

  const setTempo = (bpm) => {
    styleEngine.setTempo(bpm)
  }

  return {
    styleEngine,
    currentCategory,
    currentStyle,
    currentVariation,
    isPlaying,
    currentStep,
    currentMeasure,
    currentChord,
    startStop,
    selectCategory,
    selectStyle,
    selectVariation,
    setTempo,
    categories: STYLE_CATEGORIES,
    variations: STYLE_VARIATIONS
  }
}

