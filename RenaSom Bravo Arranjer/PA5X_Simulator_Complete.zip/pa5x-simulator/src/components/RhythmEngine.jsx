import { useState, useEffect, useRef } from 'react'

// Padrões de ritmo para diferentes estilos
const RHYTHM_PATTERNS = {
  '8Beat Pop': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    bass: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0]
  },
  '16Beat': {
    kick: [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    bass: [1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1]
  },
  'Rock': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    bass: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0]
  },
  'Jazz Swing': {
    kick: [1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1],
    snare: [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    hihat: [1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1],
    bass: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0]
  },
  'Ballad': {
    kick: [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hihat: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    bass: [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0]
  },
  'Bossa Nova': {
    kick: [1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1],
    snare: [0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0],
    hihat: [1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1],
    bass: [1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0]
  },
  'Samba': {
    kick: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    snare: [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    bass: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0]
  },
  'Country': {
    kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    hihat: [1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    bass: [1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1]
  }
}

// Progressões de acordes para diferentes estilos
const CHORD_PROGRESSIONS = {
  '8Beat Pop': ['C', 'Am', 'F', 'G'],
  '16Beat': ['C', 'G', 'Am', 'F'],
  'Rock': ['C', 'F', 'G', 'C'],
  'Jazz Swing': ['Cmaj7', 'Am7', 'Dm7', 'G7'],
  'Ballad': ['C', 'Em', 'Am', 'F', 'C', 'G', 'Am', 'F'],
  'Bossa Nova': ['Cmaj7', 'Dm7', 'G7', 'Cmaj7'],
  'Samba': ['C', 'G7', 'C', 'G7'],
  'Country': ['C', 'F', 'C', 'G', 'C']
}

export class RhythmEngine {
  constructor(audioEngine) {
    this.audioEngine = audioEngine
    this.isPlaying = false
    this.isDrumPlaying = false
    this.tempo = 120
    this.currentStyle = '8Beat Pop'
    this.currentVariation = 'MAIN A'
    this.currentStep = 0
    this.intervalId = null
    this.chordIndex = 0
    this.measureCount = 0
    
    // Callbacks para eventos
    this.onStepChange = null
    this.onChordChange = null
    this.onMeasureChange = null
  }

  setTempo(bpm) {
    this.tempo = Math.max(60, Math.min(200, bpm))
    
    if (this.isPlaying) {
      this.stop()
      this.start()
    }
  }

  setStyle(style) {
    if (RHYTHM_PATTERNS[style]) {
      this.currentStyle = style
      this.currentStep = 0
      this.chordIndex = 0
      this.measureCount = 0
    }
  }

  setVariation(variation) {
    this.currentVariation = variation
    // Diferentes variações podem ter padrões ligeiramente diferentes
    // Por simplicidade, usamos o mesmo padrão base
  }

  start() {
    if (this.isPlaying) return
    
    this.isPlaying = true
    this.currentStep = 0
    
    // Calcula o intervalo baseado no tempo (16ª notas)
    const stepInterval = (60 / this.tempo / 4) * 1000 // ms por 16ª nota
    
    this.intervalId = setInterval(() => {
      this.playStep()
      this.currentStep = (this.currentStep + 1) % 16
      
      // A cada compasso (16 steps), avança o acorde
      if (this.currentStep === 0) {
        this.measureCount++
        this.advanceChord()
        
        if (this.onMeasureChange) {
          this.onMeasureChange(this.measureCount)
        }
      }
      
      if (this.onStepChange) {
        this.onStepChange(this.currentStep)
      }
    }, stepInterval)
  }

  stop() {
    this.isPlaying = false
    
    if (this.intervalId) {
      clearInterval(this.intervalId)
      this.intervalId = null
    }
    
    // Para todas as notas
    if (this.audioEngine) {
      this.audioEngine.stopAllNotes()
    }
  }

  startDrumOnly() {
    this.isDrumPlaying = true
    if (!this.isPlaying) {
      this.start()
    }
  }

  stopDrumOnly() {
    this.isDrumPlaying = false
  }

  playStep() {
    const pattern = RHYTHM_PATTERNS[this.currentStyle]
    if (!pattern || !this.audioEngine) return

    const step = this.currentStep

    // Toca bateria se estiver ativada
    if (this.isDrumPlaying || this.isPlaying) {
      if (pattern.kick[step]) {
        this.audioEngine.playNote(36, 100, 'kick') // C2
      }
      
      if (pattern.snare[step]) {
        this.audioEngine.playNote(38, 90, 'snare') // D2
      }
      
      if (pattern.hihat[step]) {
        this.audioEngine.playNote(42, 70, 'hihat') // F#2
      }
    }

    // Toca acompanhamento se estiver em reprodução completa
    if (this.isPlaying && !this.isDrumPlaying) {
      if (pattern.bass[step]) {
        const currentChord = this.getCurrentChord()
        const bassNote = this.getChordRoot(currentChord)
        this.audioEngine.playNote(bassNote, 80, 'bass')
      }
      
      // Toca acordes em alguns steps
      if (step % 4 === 0) { // A cada 4ª nota
        this.playChord()
      }
    }
  }

  playChord() {
    const currentChord = this.getCurrentChord()
    const chordNotes = this.getChordNotes(currentChord)
    
    chordNotes.forEach((note, index) => {
      setTimeout(() => {
        this.audioEngine.playNote(note, 60, 'piano')
      }, index * 10) // Pequeno delay para arpejo
    })
  }

  getCurrentChord() {
    const progression = CHORD_PROGRESSIONS[this.currentStyle] || ['C', 'F', 'G', 'C']
    return progression[this.chordIndex % progression.length]
  }

  advanceChord() {
    const progression = CHORD_PROGRESSIONS[this.currentStyle] || ['C', 'F', 'G', 'C']
    this.chordIndex = (this.chordIndex + 1) % progression.length
    
    if (this.onChordChange) {
      this.onChordChange(this.getCurrentChord())
    }
  }

  getChordRoot(chordName) {
    const noteMap = {
      'C': 48, 'C#': 49, 'Db': 49, 'D': 50, 'D#': 51, 'Eb': 51,
      'E': 52, 'F': 53, 'F#': 54, 'Gb': 54, 'G': 55, 'G#': 56,
      'Ab': 56, 'A': 57, 'A#': 58, 'Bb': 58, 'B': 59
    }
    
    const rootNote = chordName.replace(/[^A-G#b]/g, '')
    return noteMap[rootNote] || 48 // C3 como padrão
  }

  getChordNotes(chordName) {
    const root = this.getChordRoot(chordName)
    
    // Determina o tipo de acorde
    if (chordName.includes('maj7')) {
      return [root + 12, root + 16, root + 19, root + 23] // Root, 3rd, 5th, 7th
    } else if (chordName.includes('m7')) {
      return [root + 12, root + 15, root + 19, root + 22] // Root, b3rd, 5th, b7th
    } else if (chordName.includes('7')) {
      return [root + 12, root + 16, root + 19, root + 22] // Root, 3rd, 5th, b7th
    } else if (chordName.includes('m')) {
      return [root + 12, root + 15, root + 19] // Root, b3rd, 5th
    } else {
      return [root + 12, root + 16, root + 19] // Root, 3rd, 5th (major)
    }
  }

  // Métodos para diferentes seções do estilo
  playIntro() {
    this.currentVariation = 'INTRO'
    // Implementar padrão específico de intro
  }

  playFillIn() {
    this.currentVariation = 'FILL IN'
    // Implementar fill temporário
    setTimeout(() => {
      this.currentVariation = 'MAIN A'
    }, 2000) // Volta para main após 2 segundos
  }

  playBreak() {
    this.currentVariation = 'BREAK'
    // Para o acompanhamento mas mantém a bateria
    const wasPlaying = this.isPlaying
    this.stop()
    this.isDrumPlaying = true
    
    if (wasPlaying) {
      setTimeout(() => {
        this.isDrumPlaying = false
        this.start()
        this.currentVariation = 'MAIN A'
      }, 4000) // Break de 4 segundos
    }
  }

  playEnding() {
    this.currentVariation = 'ENDING'
    // Implementar padrão de ending
    setTimeout(() => {
      this.stop()
    }, 4000) // Para após 4 segundos
  }

  getCurrentStep() {
    return this.currentStep
  }

  getCurrentMeasure() {
    return this.measureCount
  }

  isActive() {
    return this.isPlaying || this.isDrumPlaying
  }
}

// Hook React para usar o RhythmEngine
export function useRhythmEngine(audioEngine) {
  const [rhythmEngine] = useState(() => new RhythmEngine(audioEngine))
  const [isPlaying, setIsPlaying] = useState(false)
  const [isDrumPlaying, setIsDrumPlaying] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [currentChord, setCurrentChord] = useState('C')
  const [currentMeasure, setCurrentMeasure] = useState(0)

  useEffect(() => {
    // Configura callbacks
    rhythmEngine.onStepChange = setCurrentStep
    rhythmEngine.onChordChange = setCurrentChord
    rhythmEngine.onMeasureChange = setCurrentMeasure

    return () => {
      rhythmEngine.stop()
    }
  }, [rhythmEngine])

  const startStop = () => {
    if (isPlaying) {
      rhythmEngine.stop()
      setIsPlaying(false)
      setIsDrumPlaying(false)
    } else {
      rhythmEngine.start()
      setIsPlaying(true)
    }
  }

  const drumPlay = () => {
    if (isDrumPlaying) {
      rhythmEngine.stopDrumOnly()
      setIsDrumPlaying(false)
      if (!isPlaying) {
        rhythmEngine.stop()
      }
    } else {
      rhythmEngine.startDrumOnly()
      setIsDrumPlaying(true)
    }
  }

  const setTempo = (bpm) => {
    rhythmEngine.setTempo(bpm)
  }

  const setStyle = (style) => {
    rhythmEngine.setStyle(style)
  }

  const setVariation = (variation) => {
    rhythmEngine.setVariation(variation)
  }

  return {
    rhythmEngine,
    isPlaying,
    isDrumPlaying,
    currentStep,
    currentChord,
    currentMeasure,
    startStop,
    drumPlay,
    setTempo,
    setStyle,
    setVariation
  }
}

