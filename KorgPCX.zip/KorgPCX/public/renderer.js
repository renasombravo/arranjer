// PA 5X Pro Arranger - Main Audio Engine and MIDI Handler
class PA5XProArranger {
    constructor() {
        this.audioContext = null;
        this.synth = null;
        this.currentStyle = 'pop';
        this.currentSound = 'piano';
        this.isPlaying = false;
        this.tempo = 120;
        this.volume = 0.75;
        this.midiAccess = null;
        
        this.init();
    }

    async init() {
        try {
            // Don't start Tone.js here - wait for user interaction
            this.audioContext = null;
            this.synth = null;
            
            // Initialize virtual keyboard
            this.createVirtualKeyboard();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Initialize MIDI
            this.initMIDI();
            
            // Update status
            this.updateStatus('audio', 'Click START AUDIO');
            console.log('PA 5X Pro Arranger initialized successfully');
            
        } catch (error) {
            console.error('Error initializing PA 5X Pro:', error);
            this.updateStatus('audio', 'Error');
        }
    }

    createVirtualKeyboard() {
        const keyboard = document.getElementById('virtual-keyboard');
        
        // Clear existing keys
        keyboard.innerHTML = '';
        
        // Create 61 keys (C2 to C7) - standard 5-octave keyboard
        let whiteKeyIndex = 0;
        
        for (let octave = 2; octave <= 7; octave++) {
            // White keys with their MIDI note numbers (C2 = MIDI 36)
            const whiteKeyData = [
                { note: 'C', midi: (octave + 1) * 12 + 0 },
                { note: 'D', midi: (octave + 1) * 12 + 2 },
                { note: 'E', midi: (octave + 1) * 12 + 4 },
                { note: 'F', midi: (octave + 1) * 12 + 5 },
                { note: 'G', midi: (octave + 1) * 12 + 7 },
                { note: 'A', midi: (octave + 1) * 12 + 9 },
                { note: 'B', midi: (octave + 1) * 12 + 11 }
            ];
            
            // For octave 7, only create C key (final key)
            const keysToCreate = octave === 7 ? 1 : 7;
            
            for (let i = 0; i < keysToCreate; i++) {
                const { note, midi } = whiteKeyData[i];
                
                // Create white key
                const whiteKey = document.createElement('div');
                whiteKey.className = 'key white';
                whiteKey.dataset.note = `${note}${octave}`;
                whiteKey.dataset.midi = midi;
                whiteKey.dataset.frequency = this.noteToFreq(midi);
                whiteKey.style.left = `${whiteKeyIndex * (100/36)}%`; // 36 white keys total
                whiteKey.style.width = `${100/36}%`;
                
                keyboard.appendChild(whiteKey);
                
                // Add black keys where they exist (no black key after E and B, and not for final C7)
                if (note !== 'E' && note !== 'B' && octave < 7) {
                    const blackKey = document.createElement('div');
                    blackKey.className = 'key black';
                    const blackNote = note + '#';
                    blackKey.dataset.note = `${blackNote}${octave}`;
                    blackKey.dataset.midi = midi + 1;
                    blackKey.dataset.frequency = this.noteToFreq(midi + 1);
                    
                    // Position black key between current and next white key
                    const blackKeyLeft = (whiteKeyIndex + 0.7) * (100/36);
                    blackKey.style.left = `${blackKeyLeft}%`;
                    blackKey.style.width = '2.2%';
                    
                    keyboard.appendChild(blackKey);
                }
                
                whiteKeyIndex++;
            }
        }
    }

    noteToFreq(noteNum) {
        return 440 * Math.pow(2, (noteNum - 69) / 12);
    }

    setupEventListeners() {
        // Start Audio button
        const startAudioBtn = document.getElementById('start-audio-btn');
        if (startAudioBtn) {
            startAudioBtn.addEventListener('click', async () => {
                try {
                    await Tone.start();
                    this.audioContext = Tone.context;
                    
                    // Create synthesizer after user interaction
                    this.synth = new Tone.PolySynth(Tone.Synth, {
                        oscillator: { type: 'sawtooth' },
                        envelope: { attack: 0.01, decay: 0.2, sustain: 0.5, release: 0.3 }
                    }).toDestination();

                    // Set initial volume
                    this.synth.volume.value = Tone.gainToDb(this.volume);
                    
                    startAudioBtn.textContent = '✅ AUDIO ACTIVE';
                    startAudioBtn.classList.add('activated');
                    startAudioBtn.disabled = true;
                    this.updateDisplay('Audio system activated - Ready to play!');
                    this.updateStatus('audio', 'Ready');
                } catch (error) {
                    console.error('Failed to start audio:', error);
                    this.updateDisplay('Audio activation failed');
                    this.updateStatus('audio', 'Error');
                }
            });
        }

        // Virtual keyboard events
        const keys = document.querySelectorAll('.key');
        keys.forEach(key => {
            key.addEventListener('mousedown', (e) => this.playNote(e.target));
            key.addEventListener('mouseup', (e) => this.stopNote(e.target));
            key.addEventListener('mouseleave', (e) => this.stopNote(e.target));
        });

        // Style selection
        const styleButtons = document.querySelectorAll('.style-btn');
        styleButtons.forEach(btn => {
            btn.addEventListener('click', (e) => this.selectStyle(e.target.dataset.style));
        });

        // Sound selection
        const soundButtons = document.querySelectorAll('.sound-btn');
        soundButtons.forEach(btn => {
            btn.addEventListener('click', (e) => this.selectSound(e.target.dataset.sound));
        });

        // Transport controls
        document.getElementById('start-stop-btn').addEventListener('click', () => this.togglePlayback());
        document.getElementById('tap-tempo-btn').addEventListener('click', () => this.tapTempo());

        // Volume control
        const volumeSlider = document.getElementById('master-volume');
        volumeSlider.addEventListener('input', (e) => this.setVolume(e.target.value / 100));

        // Tempo control
        const tempoSlider = document.getElementById('tempo-slider');
        tempoSlider.addEventListener('input', (e) => this.setTempo(e.target.value));

        // Keyboard events for computer keyboard playing
        document.addEventListener('keydown', (e) => this.handleKeyDown(e));
        document.addEventListener('keyup', (e) => this.handleKeyUp(e));
    }

    async initMIDI() {
        try {
            if (navigator.requestMIDIAccess) {
                this.midiAccess = await navigator.requestMIDIAccess();
                this.setupMIDIEventListeners();
                this.updateStatus('midi', 'Ready');
                console.log('MIDI initialized successfully');
            } else {
                console.warn('Web MIDI API not supported');
                this.updateStatus('midi', 'Not Supported');
            }
        } catch (error) {
            console.error('MIDI initialization failed:', error);
            this.updateStatus('midi', 'Error');
        }
    }

    setupMIDIEventListeners() {
        for (let input of this.midiAccess.inputs.values()) {
            input.onmidimessage = (message) => this.handleMIDIMessage(message);
            console.log(`Connected to MIDI input: ${input.name}`);
            this.updateStatus('midi', `Connected: ${input.name}`);
        }

        this.midiAccess.onstatechange = (event) => {
            if (event.port.type === 'input') {
                if (event.port.state === 'connected') {
                    event.port.onmidimessage = (message) => this.handleMIDIMessage(message);
                    this.updateStatus('midi', `Connected: ${event.port.name}`);
                } else {
                    this.updateStatus('midi', 'Disconnected');
                }
            }
        };
    }

    handleMIDIMessage(message) {
        const [command, note, velocity] = message.data;
        const channel = command & 0xf;
        const messageType = command & 0xf0;

        if (messageType === 0x90 && velocity > 0) {
            // Note on
            this.playMIDINote(note, velocity / 127);
        } else if (messageType === 0x80 || (messageType === 0x90 && velocity === 0)) {
            // Note off
            this.stopMIDINote(note);
        }
    }

    playNote(keyElement) {
        if (!keyElement.dataset.frequency) return;
        
        const freq = parseFloat(keyElement.dataset.frequency);
        keyElement.classList.add('pressed');
        
        // Play the note if synth is available
        if (this.synth) {
            this.synth.triggerAttack(freq);
        }
    }

    stopNote(keyElement) {
        if (!keyElement.dataset.frequency) return;
        
        const freq = parseFloat(keyElement.dataset.frequency);
        keyElement.classList.remove('pressed');
        
        // Stop the note if synth is available
        if (this.synth) {
            this.synth.triggerRelease(freq);
        }
    }

    playMIDINote(noteNumber, velocity) {
        const freq = this.noteToFreq(noteNumber);
        
        // Play the note if synth is available
        if (this.synth) {
            this.synth.triggerAttack(freq, '+0', velocity);
        }
        
        // Visual feedback on virtual keyboard
        const keyElement = document.querySelector(`[data-midi="${noteNumber}"]`);
        if (keyElement) {
            keyElement.classList.add('pressed');
        }
    }

    stopMIDINote(noteNumber) {
        const freq = this.noteToFreq(noteNumber);
        
        // Stop the note if synth is available
        if (this.synth) {
            this.synth.triggerRelease(freq);
        }
        
        // Remove visual feedback
        const keyElement = document.querySelector(`[data-midi="${noteNumber}"]`);
        if (keyElement) {
            keyElement.classList.remove('pressed');
        }
    }

    selectStyle(style) {
        this.currentStyle = style;
        
        // Update UI
        document.querySelectorAll('.style-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelector(`[data-style="${style}"]`).classList.add('active');
        
        // Update display
        this.updateDisplay(`Style: ${style.toUpperCase()}`);
        
        console.log(`Style changed to: ${style}`);
    }

    selectSound(sound) {
        this.currentSound = sound;
        
        // Update synthesizer based on sound selection
        this.updateSynthSound(sound);
        
        // Update display
        this.updateDisplay(`Sound: ${sound.toUpperCase()}`);
        
        console.log(`Sound changed to: ${sound}`);
    }

    updateSynthSound(sound) {
        if (!this.synth) return;
        
        // Simple sound modifications based on selection
        const soundSettings = {
            piano: { type: 'sine', attack: 0.01, decay: 0.3, sustain: 0.8, release: 1.0 },
            organ: { type: 'square', attack: 0.01, decay: 0.1, sustain: 0.9, release: 0.1 },
            strings: { type: 'sawtooth', attack: 0.3, decay: 0.2, sustain: 0.8, release: 2.0 },
            brass: { type: 'square', attack: 0.1, decay: 0.2, sustain: 0.7, release: 0.5 },
            guitar: { type: 'triangle', attack: 0.01, decay: 0.5, sustain: 0.3, release: 1.0 },
            bass: { type: 'sine', attack: 0.01, decay: 0.3, sustain: 0.7, release: 0.8 },
            drums: { type: 'square', attack: 0.01, decay: 0.1, sustain: 0.1, release: 0.1 },
            synth: { type: 'sawtooth', attack: 0.01, decay: 0.2, sustain: 0.5, release: 0.3 }
        };

        const settings = soundSettings[sound] || soundSettings.piano;
        
        // Update oscillator and envelope
        this.synth.set({
            oscillator: { type: settings.type },
            envelope: {
                attack: settings.attack,
                decay: settings.decay,
                sustain: settings.sustain,
                release: settings.release
            }
        });
    }

    togglePlayback() {
        this.isPlaying = !this.isPlaying;
        const btn = document.getElementById('start-stop-btn');
        
        if (this.isPlaying) {
            btn.textContent = 'STOP';
            btn.style.background = 'linear-gradient(135deg, #cc0000, #880000)';
            this.updateDisplay('Playing...');
        } else {
            btn.textContent = 'START/STOP';
            btn.style.background = 'linear-gradient(135deg, #006600, #004400)';
            this.updateDisplay('Stopped');
        }
        
        console.log(`Playback ${this.isPlaying ? 'started' : 'stopped'}`);
    }

    setVolume(volume) {
        this.volume = volume;
        if (this.synth) {
            this.synth.volume.value = Tone.gainToDb(volume);
        }
        document.getElementById('volume-display').textContent = Math.round(volume * 100);
    }

    setTempo(tempo) {
        this.tempo = parseInt(tempo);
        Tone.Transport.bpm.value = this.tempo;
        document.getElementById('tempo-display').textContent = this.tempo;
        this.updateDisplay(`Tempo: ${this.tempo} BPM`);
    }

    tapTempo() {
        // Simple tap tempo implementation
        const now = Date.now();
        if (!this.lastTap) {
            this.lastTap = now;
            return;
        }
        
        const interval = now - this.lastTap;
        const newTempo = Math.round(60000 / interval);
        
        if (newTempo >= 60 && newTempo <= 200) {
            this.setTempo(newTempo);
            document.getElementById('tempo-slider').value = newTempo;
        }
        
        this.lastTap = now;
    }

    updateDisplay(message) {
        const display = document.querySelector('.display-content p');
        if (display) {
            display.textContent = message;
        }
    }

    updateStatus(type, status) {
        const statusElement = document.getElementById(`${type}-status`);
        if (statusElement) {
            statusElement.textContent = status;
        }
    }

    handleKeyDown(e) {
        // Map computer keyboard to piano keys
        const keyMap = {
            'a': 60, 'w': 61, 's': 62, 'e': 63, 'd': 64, 'f': 65, 't': 66, 'g': 67, 'y': 68, 'h': 69, 'u': 70, 'j': 71, 'k': 72
        };
        
        const note = keyMap[e.key.toLowerCase()];
        if (note && !e.repeat) {
            this.playMIDINote(note, 0.8);
        }
    }

    handleKeyUp(e) {
        const keyMap = {
            'a': 60, 'w': 61, 's': 62, 'e': 63, 'd': 64, 'f': 65, 't': 66, 'g': 67, 'y': 68, 'h': 69, 'u': 70, 'j': 71, 'k': 72
        };
        
        const note = keyMap[e.key.toLowerCase()];
        if (note) {
            this.stopMIDINote(note);
        }
    }
}

// Initialize the PA 5X Pro Arranger when the page loads
window.addEventListener('DOMContentLoaded', () => {
    window.pa5xPro = new PA5XProArranger();
    console.log('PA 5X Pro Arranger software ready!');
});