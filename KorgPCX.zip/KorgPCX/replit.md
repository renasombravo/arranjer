# PA 5X Pro Arranger - Professional Keyboard Workstation

## Overview

The PA 5X Pro Arranger is a complete software replica of the Korg PA 5X Pro arranger keyboard, designed as a professional keyboard workstation. This application provides a comprehensive digital music creation environment with style-based accompaniment, MIDI support, virtual keyboard interface, and professional audio synthesis capabilities. The project serves as both a standalone desktop application and a web-based interface for musicians and producers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a dual-deployment approach with both Electron desktop and web-based interfaces. The frontend is built with vanilla HTML, CSS, and JavaScript, creating a realistic keyboard workstation interface that mimics professional hardware. The main interface features an LCD-style display, navigation controls, style selection buttons, and a virtual keyboard for interaction.

### Desktop Application Framework
Built on Electron for cross-platform desktop deployment, providing native app capabilities while leveraging web technologies. The main process handles window management and system integration, while the renderer process manages the audio engine and user interface.

### Audio Engine
The core audio system is powered by Tone.js, a comprehensive Web Audio API framework that provides:
- Polyphonic synthesis capabilities
- Real-time audio processing
- MIDI input handling
- Professional-grade sound generation
- Style-based accompaniment patterns

### MIDI Integration
Native MIDI support through Web MIDI API allows the application to:
- Connect with external MIDI controllers
- Receive real-time MIDI input
- Process note on/off events
- Handle control change messages
- Support standard MIDI protocol communication

### Virtual Keyboard Interface
A software-based 61-key keyboard (C2 to C7) provides:
- Visual feedback for played notes
- Mouse/touch interaction capabilities
- Real-time audio synthesis
- Integration with MIDI input systems

### State Management
The application manages multiple state layers including:
- Current musical style selection (Pop, Rock, Jazz, Latin)
- Active sound presets and synthesis parameters
- Tempo and key signature settings
- Audio engine status and initialization state
- MIDI device connection status

### Server Architecture
An Express.js server provides web interface hosting capabilities, serving static assets and handling HTTP requests for web-based deployment scenarios.

## External Dependencies

### Audio Processing
- **Tone.js (v15.1.22)**: Primary audio synthesis and Web Audio API framework
- **midi-player-js (v2.0.16)**: MIDI file playback and sequencing

### Desktop Application
- **Electron (v38.1.0)**: Cross-platform desktop application framework
- **electron-builder (v26.0.12)**: Application packaging and distribution

### Web Server
- **Express.js (v5.1.0)**: Web server framework for hosting the interface
- **Node.js path module**: File system path utilities

### Browser APIs
- **Web Audio API**: Core audio processing and synthesis
- **Web MIDI API**: External MIDI controller integration
- **Canvas/WebGL**: Potential graphics rendering for visual elements

The application requires modern browser support for Web Audio and Web MIDI APIs, with fallback handling for environments where these features are unavailable.